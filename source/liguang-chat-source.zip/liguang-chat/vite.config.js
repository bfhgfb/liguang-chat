import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { viteSingleFile } from 'vite-plugin-singlefile'

// 打包成单个 HTML，方便直接放到安卓 WebView / 手机浏览器打开
export default defineConfig({
  plugins: [vue(), viteSingleFile()],
  base: './',
  server: {
    port: 5173,
    host: true,
    proxy: {
      '/api': { target: 'http://localhost:8787', changeOrigin: true },
      '/uploads': { target: 'http://localhost:8787', changeOrigin: true },
      '/socket.io': { target: 'http://localhost:8787', ws: true }
    }
  },
  build: {
    target: 'es2018',
    assetsInlineLimit: 1024 * 1024,
    cssCodeSplit: false
  }
})
