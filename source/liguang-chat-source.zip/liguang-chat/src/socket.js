import { io } from 'socket.io-client'

let socket = null

export function connectSocket(token, handlers) {
  disconnectSocket()
  socket = io(window.__API_ORIGIN__ || '/', {
    auth: { token },
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 800,
    reconnectionAttempts: Infinity
  })

  Object.keys(handlers || {}).forEach(event => {
    socket.on(event, payload => {
      try {
        handlers[event](payload)
      } catch (e) {
        console.warn('socket handler error', event, e)
      }
    })
  })

  socket.on('connect_error', err => {
    console.warn('socket connect_error:', err.message)
  })

  return socket
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect()
    socket = null
  }
}
