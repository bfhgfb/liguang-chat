import { computed, reactive, watch } from 'vue'
import { supabase } from './supabase'

/* ============================================================
 * 璃光聊 · Supabase 数据层
 * 认证 / 数据库 / 实时 / 文件存储 全部直连 Supabase
 * 不需要任何自建服务器
 * ============================================================ */

const PREF_KEY = 'liguang_prefs_v1'

function loadPrefs() {
  try {
    return JSON.parse(localStorage.getItem(PREF_KEY) || '{}')
  } catch (e) {
    return {}
  }
}

const prefs = loadPrefs()

export const state = reactive({
  token: '',
  me: null,
  friends: [],
  requests: [],
  chats: [],
  messages: {},
  moments: [],
  users: {},
  remarks: {},
  activeChatId: null,
  ready: false,
  consented: Boolean(prefs.consented),
  pinned: prefs.pinned || {},
  muted: prefs.muted || {},
  blocked: prefs.blocked || [],
  kickedMsg: '',
  settings: Object.assign({ friendVerify: true, allowStrangerMoments: false }, prefs.settings || {}),

  /* 弱网重试状态：>0 表示正在自动重试第几次 */
  authRetry: 0
})

watch(
  () => [state.pinned, state.muted, state.blocked, state.settings, state.consented],
  () => {
    try {
      localStorage.setItem(
        PREF_KEY,
        JSON.stringify({
          pinned: state.pinned,
          muted: state.muted,
          blocked: state.blocked,
          settings: state.settings,
          consented: state.consented
        })
      )
    } catch (e) {
      /* ignore */
    }
  },
  { deep: true }
)

/* ---------------- 错误文案 ---------------- */

function fail(e, fallback = '操作失败，请重试') {
  if (!e) return new Error(fallback)
  const raw = String(e.message || e.error_description || e || fallback)
  const map = [
    ['Failed to fetch', '连不上服务器：请先切换 Wi-Fi / 4G 再试，并确认手机时间是自动校准的'],
    ['Load failed', '连不上服务器：请先切换 Wi-Fi / 4G 再试，并确认手机时间是自动校准的'],
    ['NetworkError', '连不上服务器：请先切换 Wi-Fi / 4G 再试，并确认手机时间是自动校准的'],
    ['Invalid login credentials', '账号或密码错误'],
    ['Email not confirmed', '账号还没激活：请到 Supabase 控制台关闭邮箱确认后再登录'],
    ['User already registered', '该账号已被注册'],
    ['Password should be at least 6 characters', '密码至少 6 位'],
    ['Email address is invalid', '账号格式不正确（只能用 3-20 位字母或数字）'],
    ['New row violates row-level security policy', '没有权限执行该操作']
  ]
  for (const [k, v] of map) if (raw.includes(k)) return new Error(v)
  return new Error(raw)
}

/* ---------------- 用户缓存 ---------------- */

function cacheUser(user) {
  if (!user || !user.id) return
  state.users[user.id] = { ...state.users[user.id], ...user }
}

export function userById(id) {
  if (!id) return null
  if (state.me && id === state.me.id) return state.me
  return state.users[id] || null
}

function ensureUser(id) {
  if (!id || userById(id)) return
  supabase
    .from('profiles')
    .select('*')
    .eq('id', id)
    .maybeSingle()
    .then(({ data }) => {
      if (data) cacheUser(data)
    })
}

/* ---------------- 登录态 ---------------- */

export function setConsented(v) {
  state.consented = Boolean(v)
}

export async function isAuthed() {
  const { data } = await supabase.auth.getSession()
  return Boolean(data.session)
}

function applySession(session) {
  state.token = session?.access_token || ''
}

function clearState() {
  state.token = ''
  state.me = null
  state.friends = []
  state.requests = []
  state.chats = []
  state.messages = {}
  state.moments = []
  state.users = {}
  state.ready = false
  state.activeChatId = null
}

export async function initAuth() {
  const { data } = await supabase.auth.getSession()
  const session = data.session
  if (!session) {
    clearState()
    return false
  }
  applySession(session)
  try {
    await refresh()
  } catch (e) {
    console.warn('bootstrap failed', e)
    const meta = session.user.user_metadata || {}
    state.me = {
      id: session.user.id,
      username: meta.username || '',
      nickname: meta.nickname || '我'
    }
    cacheUser(state.me)
  }
  if (!state.me) return false
  startRealtime()
  startPolling()
  return true
}

async function afterLogin(session) {
  applySession(session)
  state.ready = false
  try {
    await refresh()
  } catch (e) {
    if (!isNetworkError(e)) throw e
    await new Promise(r => setTimeout(r, 1200))
    await refresh()
  }
  if (!state.me) throw new Error(state.kickedMsg || '登录失败，请重试')
  startRealtime()
  startPolling()
  state.ready = true
  return state.me
}

const EMAIL_DOMAIN = '@liguang.app'

function usernameToEmail(username) {
  return String(username || '').trim().toLowerCase() + EMAIL_DOMAIN
}

/* 弱网保护：超时 + 自动重试（只对网络类错误重试） */
const AUTH_TIMEOUT = 15000

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('TIMEOUT')), ms)
    Promise.resolve(promise).then(
      v => {
        clearTimeout(timer)
        resolve(v)
      },
      e => {
        clearTimeout(timer)
        reject(e)
      }
    )
  })
}

function isNetworkError(e) {
  return /Failed to fetch|Load failed|NetworkError|TIMEOUT|network|fetch/i.test(
    String((e && e.message) || e || '')
  )
}

async function withRetry(fn, tries = 3) {
  let last
  for (let i = 0; i < tries; i++) {
    try {
      const result = await withTimeout(fn(), AUTH_TIMEOUT)
      state.authRetry = 0
      return result
    } catch (e) {
      last = e
      if (!isNetworkError(e) || i === tries - 1) {
        state.authRetry = 0
        throw e
      }
      state.authRetry = i + 1
      await new Promise(r => setTimeout(r, 1200 * (i + 1)))
    }
  }
  state.authRetry = 0
  throw last
}

function netFail(e) {
  if (isNetworkError(e)) {
    return new Error('连不上服务器：已自动重试 3 次。请切换 Wi-Fi / 4G，确认手机时间正确后再试。')
  }
  return fail(e)
}

export async function login(username, password) {
  const email = usernameToEmail(username)
  let res
  try {
    res = await withRetry(() => supabase.auth.signInWithPassword({ email, password }))
  } catch (e) {
    throw netFail(e)
  }
  if (res.error) throw fail(res.error)
  const { data } = await supabase.auth.getSession()
  if (!data.session) throw new Error('登录失败，请重试')
  return afterLogin(data.session)
}

async function finishRegister(session) {
  const me = await afterLogin(session)
  try {
    await setPrivacy(state.settings.friendVerify, true)
  } catch (e) {
    /* 动态全公开设置失败时不影响注册 */
  }
  return me
}

export async function register(username, password, nickname) {
  const name = String(username || '').trim().toLowerCase()
  if (!/^[a-z0-9_-]{3,20}$/.test(name)) {
    throw new Error('账号只能用 3-20 位字母、数字、下划线或减号')
  }
  const email = name + EMAIL_DOMAIN
  let res
  try {
    res = await withRetry(() =>
      supabase.auth.signUp({
        email,
        password,
        options: { data: { username: name, nickname: String(nickname || '').trim() || name } }
      })
    )
  } catch (e) {
    throw netFail(e)
  }
  const { data, error } = res
  if (error) throw fail(error)

  if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
    // 可能是上一次请求其实已注册成功（弱网重试导致），尝试直接登录
    let again = null
    try {
      again = await withRetry(() => supabase.auth.signInWithPassword({ email, password }), 2)
    } catch (e) {
      again = null
    }
    if (again && !again.error && again.data && again.data.session) {
      return finishRegister(again.data.session)
    }
    throw new Error('该账号已被注册，请换一个账号或直接登录')
  }
  if (!data.session) {
    throw new Error(
      '账号已创建，但项目还开着“邮箱确认”。请到 Supabase 控制台 → Authentication → Providers → Email，关闭 Confirm email 后，再回来登录。'
    )
  }
  return finishRegister(data.session)
}

export function logout() {
  clearState()
  stopRealtime()
  stopPolling()
  supabase.auth.signOut().catch(() => {})
}

/* ---------------- 基础拉取 ---------------- */

function previewOf(last) {
  if (!last) return '还没有消息'
  if (last.recalled) {
    return last.fromId === state.me?.id ? '你撤回了一条消息' : '对方撤回了一条消息'
  }
  if (last.type === 'image') return '[图片]'
  if (last.type === 'voice') return '[语音]'
  return last.content
}

function normalizeChat(c) {
  const members = c.members || []
  members.forEach(cacheUser)
  const peer = c.type === 'direct'
    ? members.find(m => m.id !== state.me?.id) || members[0] || null
    : null
  const title = c.type === 'group'
    ? c.name
    : ((peer && (state.remarks[peer.id] || peer.nickname)) || '聊天')
  return {
    ...c,
    members,
    peer,
    title,
    preview: previewOf(c.lastMessage),
    unread: c.unread || 0,
    pinned: Boolean(state.pinned[c.id]),
    muted: Boolean(state.muted[c.id]),
    lastAt: c.lastAt || (c.lastMessage && c.lastMessage.at) || c.createdAt || 0
  }
}

function upsertChat(raw) {
  const chat = normalizeChat(raw)
  const i = state.chats.findIndex(c => c.id === chat.id)
  if (i > -1) state.chats[i] = chat
  else state.chats.push(chat)
  return chat
}

export async function refresh() {
  const { data, error } = await supabase.rpc('bootstrap')
  if (error) throw fail(error)
  const payload = data || {}

  if (payload.me) {
    if (payload.me.disabled) {
      state.kickedMsg = '该账号已被小杜官方停用，如有疑问请通过官方账号咨询'
      logout()
      try {
        if (typeof location !== 'undefined' && location.hash !== '#/login') location.hash = '#/login'
      } catch (e) {
        /* ignore */
      }
      return state
    }
    state.me = payload.me
    cacheUser(payload.me)
    state.settings.friendVerify = payload.me.friend_verify !== false
    state.settings.allowStrangerMoments = Boolean(payload.me.allow_stranger_moments)
  }
  state.friends = (payload.friends || []).map(p => {
    cacheUser(p)
    return p
  })
  state.remarks = {}
  state.friends.forEach(f => {
    if (f.remark) state.remarks[f.id] = f.remark
  })
  state.requests = (payload.requests || []).map(r => {
    cacheUser(r.user)
    cacheUser(r.peer)
    return { ...r, peer: r.peer || r.user }
  })
  state.chats = (payload.chats || []).map(c => normalizeChat(c))
  if (Array.isArray(payload.blocked)) state.blocked = payload.blocked
  state.ready = true
  return state
}

/* ---------------- 查询 ---------------- */

export function chatById(id) {
  return state.chats.find(c => c.id === id) || null
}

export function chatByPeer(peerId) {
  return state.chats.find(c => c.type === 'direct' && c.peer && c.peer.id === peerId) || null
}

export function messagesOf(chatId) {
  return state.messages[chatId] || []
}

export function isFriend(id) {
  return state.friends.some(f => f.id === id)
}

export function displayName(user) {
  if (!user) return '用户'
  return state.remarks[user.id] || user.nickname || user.username || '用户'
}

export function isBlocked(id) {
  return state.blocked.includes(id)
}

export const friendList = computed(() => state.friends)

export const pendingRequests = computed(() => state.requests.filter(r => r.status === 'waiting'))

export const chatList = computed(() =>
  [...state.chats]
    .filter(c => !(c.type === 'direct' && c.peer && state.blocked.includes(c.peer.id)))
    .sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1
      return (b.lastAt || 0) - (a.lastAt || 0)
    })
)

export const totalUnread = computed(() =>
  state.chats.reduce((sum, c) => (c.muted ? sum : sum + (c.unread || 0)), 0)
)

/* ---------------- 聊天 ---------------- */

export function setActiveChat(id) {
  state.activeChatId = id
  if (id) {
    const chat = chatById(id)
    if (chat) chat.unread = 0
  }
}

export async function loadMessages(chatId) {
  const { data, error } = await supabase.rpc('get_messages', { cid: chatId })
  if (error) throw fail(error)
  const list = (data || []).slice().sort((a, b) => a.at - b.at)
  state.messages[chatId] = list
  return list
}

function addLocalMessage(chatId, message) {
  if (!state.messages[chatId]) return
  if (state.messages[chatId].some(m => m.id === message.id)) return
  const list = state.messages[chatId]
  list.push(message)
  list.sort((a, b) => a.at - b.at)
}

function touchChat(chatId, message) {
  const chat = chatById(chatId)
  if (!chat) return
  chat.lastMessage = message
  chat.lastAt = message.at
  chat.preview = previewOf(message)
}

export async function sendMessage(chatId, { type = 'text', content = '', duration = 0 } = {}) {
  const { data, error } = await supabase.rpc('send_message', {
    cid: chatId,
    mtype: type,
    mcontent: content,
    mduration: duration
  })
  if (error) throw fail(error)
  const message = data
  addLocalMessage(chatId, message)
  touchChat(chatId, message)
  const chat = chatById(chatId)
  if (chat) chat.unread = 0
  return message
}

export async function recallMessage(chatId, messageId) {
  const { data, error } = await supabase.rpc('recall_message', { mid: messageId })
  if (error) throw fail(error)
  const list = state.messages[chatId] || []
  const local = list.find(m => m.id === messageId)
  if (local) Object.assign(local, data)
  const chat = chatById(chatId)
  if (chat) touchChat(chatId, data)
  return data
}

export async function deleteMessage(chatId, messageId) {
  const { error } = await supabase.rpc('delete_message', { mid: messageId })
  if (error) throw fail(error)
  const list = state.messages[chatId] || []
  const i = list.findIndex(m => m.id === messageId)
  if (i > -1) list.splice(i, 1)
}

export async function markRead(chatId) {
  const chat = chatById(chatId)
  if (chat) chat.unread = 0
  const { error } = await supabase.rpc('mark_read', { cid: chatId })
  if (error) console.warn('mark_read', error.message)
}

export async function openDirect(peerId) {
  const { data, error } = await supabase.rpc('open_direct', { peer: peerId })
  if (error) throw fail(error)
  return upsertChat(data)
}

export async function createGroup(name, memberIds) {
  const { data, error } = await supabase.rpc('create_group', { gname: name, member_ids: memberIds })
  if (error) throw fail(error)
  return upsertChat(data)
}

export function togglePin(chatId) {
  state.pinned[chatId] = !state.pinned[chatId]
  const chat = chatById(chatId)
  if (chat) chat.pinned = Boolean(state.pinned[chatId])
}

export function toggleMute(chatId) {
  state.muted[chatId] = !state.muted[chatId]
  const chat = chatById(chatId)
  if (chat) chat.muted = Boolean(state.muted[chatId])
}

/* ---------------- 好友 ---------------- */

export async function searchUser(q) {
  const { data, error } = await supabase.rpc('search_user', { q: String(q || '') })
  if (error) throw fail(error)
  if (data) cacheUser(data)
  return data || null
}

export async function sendFriendRequest(toId) {
  const { data, error } = await supabase.rpc('send_friend_request', { to_uid: toId })
  if (error) throw fail(error)
  await refresh()
  return data
}

export async function acceptRequest(requestId) {
  const { data, error } = await supabase.rpc('respond_request', { rid: requestId, p_action: 'accept' })
  if (error) throw fail(error)
  await refresh()
  return data
}

export async function rejectRequest(requestId) {
  const { data, error } = await supabase.rpc('respond_request', { rid: requestId, p_action: 'reject' })
  if (error) throw fail(error)
  await refresh()
  return data
}

export async function removeFriend(id) {
  const { error } = await supabase.rpc('remove_friend', { fid: id })
  if (error) throw fail(error)
  await refresh()
}

export async function setFriendRemark(fid, rname) {
  const { error } = await supabase.rpc('set_friend_remark', { fid, rname: rname || '' })
  if (error) throw fail(error)
  const v = String(rname || '').trim()
  const friend = state.friends.find(f => f.id === fid)
  if (friend) friend.remark = v
  if (v) state.remarks[fid] = v
  else delete state.remarks[fid]
  state.chats = state.chats.map(c => {
    if (c.type !== 'direct' || !c.peer || c.peer.id !== fid) return c
    return { ...c, title: v || c.peer.nickname || '聊天' }
  })
  return v
}

export async function blockUser(id) {
  const { error } = await supabase.rpc('block_user', { bid: id })
  if (error) throw fail(error)
  if (!state.blocked.includes(id)) state.blocked.push(id)
  state.chats = state.chats.filter(c => !(c.type === 'direct' && c.peer && c.peer.id === id))
}

export async function unblockUser(id) {
  const { error } = await supabase.rpc('unblock_user', { bid: id })
  if (error) throw fail(error)
  const i = state.blocked.indexOf(id)
  if (i > -1) state.blocked.splice(i, 1)
}

export async function loadBlockedUsers() {
  const { data, error } = await supabase.rpc('list_blocked')
  if (error) throw fail(error)
  return (data || []).map(p => {
    cacheUser(p)
    return p
  })
}

/* ---------------- 朋友圈 ---------------- */

export async function loadMoments() {
  const { data, error } = await supabase.rpc('list_moments')
  if (error) throw fail(error)
  state.moments = (data || []).map(m => {
    cacheUser(m.user)
    ;(m.comments || []).forEach(c => cacheUser(c.user))
    return m
  })
  return state.moments
}

export async function createMoment(text, images) {
  const { error } = await supabase.rpc('create_moment', {
    mtext: text,
    mimages: images || []
  })
  if (error) throw fail(error)
  await loadMoments()
}

export async function likeMoment(id) {
  const { data, error } = await supabase.rpc('toggle_moment_like', { mid: id })
  if (error) throw fail(error)
  const moment = state.moments.find(m => m.id === id)
  if (moment && data) {
    moment.liked = data.liked
    moment.likeCount = data.likeCount
  }
  return data
}

export async function commentMoment(id, text) {
  const { data, error } = await supabase.rpc('add_moment_comment', { mid: id, ctext: text })
  if (error) throw fail(error)
  const moment = state.moments.find(m => m.id === id)
  if (moment) {
    if (!moment.comments) moment.comments = []
    moment.comments.push(data)
    cacheUser(data.user)
  }
  return data
}

/* ---------------- 上传 ---------------- */

const EXT_BY_TYPE = {
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'audio/webm': 'webm',
  'audio/ogg': 'ogg',
  'audio/mp4': 'm4a',
  'audio/mpeg': 'mp3',
  'audio/wav': 'wav'
}

function dataUrlToBlob(dataUrl) {
  const comma = dataUrl.indexOf(',')
  const head = dataUrl.slice(0, comma)
  const body = dataUrl.slice(comma + 1)
  const mime = (/data:([^;]+)/.exec(head) || [])[1] || 'application/octet-stream'
  const bin = atob(body)
  const bytes = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i)
  return new Blob([bytes], { type: mime })
}

export async function uploadDataUrl(dataUrl) {
  if (!state.me) throw new Error('请先登录')
  const blob = dataUrlToBlob(dataUrl)
  const mime = (blob.type || '').split(';')[0]
  const ext = EXT_BY_TYPE[mime] || 'bin'
  const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`
  const path = `${state.me.id}/${name}`
  const { error } = await supabase.storage.from('media').upload(path, blob, {
    contentType: mime || 'application/octet-stream',
    upsert: false,
    cacheControl: '31536000'
  })
  if (error) throw new Error('上传失败：' + (error.message || '网络异常'))
  const { data } = supabase.storage.from('media').getPublicUrl(path)
  return data.publicUrl
}

/* ---------------- 我的资料 ---------------- */

export async function updateProfile(patch) {
  if (!state.me) throw new Error('请先登录')
  const clean = {}
  for (const key of ['nickname', 'bio', 'avatar_url']) {
    if (patch[key] !== undefined) clean[key] = patch[key]
  }
  const { error } = await supabase.from('profiles').update(clean).eq('id', state.me.id)
  if (error) throw fail(error)
  state.me = { ...state.me, ...clean }
  cacheUser(state.me)
  return state.me
}

export async function uploadAvatar(dataUrl) {
  const url = await uploadDataUrl(dataUrl)
  await updateProfile({ avatar_url: url })
  return url
}

export function profileLink(username) {
  return `https://bfhgfb.github.io/liguang-chat/#/add?u=${encodeURIComponent(username || '')}`
}

/* ---------------- 官方账号 / 用户管理 ---------------- */

export function isOfficial(user) {
  return Boolean((user || state.me || {}).is_official)
}

export async function adminListUsers() {
  const { data, error } = await supabase.rpc('admin_list_users')
  if (error) throw fail(error)
  return data || []
}

export async function adminSetDisabled(id, flag) {
  const { data, error } = await supabase.rpc('admin_set_disabled', { target: id, flag })
  if (error) throw fail(error)
  const target = state.users[id]
  if (target) target.disabled = Boolean(flag)
  return data
}

export async function adminTogglePin(id) {
  const { data, error } = await supabase.rpc('admin_toggle_pin', { mid: id })
  if (error) throw fail(error)
  await loadMoments()
  return data
}

export async function adminDeleteMoment(id) {
  const { error } = await supabase.rpc('admin_delete_moment', { mid: id })
  if (error) throw fail(error)
  state.moments = state.moments.filter(m => m.id !== id)
}

export async function adminDeleteComment(momentId, commentId) {
  const { error } = await supabase.rpc('admin_delete_comment', { cid: commentId })
  if (error) throw fail(error)
  const moment = state.moments.find(m => m.id === momentId)
  if (moment && moment.comments) {
    moment.comments = moment.comments.filter(c => c.id !== commentId)
  }
}

export async function adminUpdateProfile(target, patch) {
  if (!state.me) throw new Error('请先登录')
  const { data, error } = await supabase.rpc('admin_update_profile', {
    target,
    p_nickname: patch.nickname,
    p_bio: patch.bio,
    p_avatar_url: patch.avatar_url
  })
  if (error) throw fail(error)
  cacheUser(data)
  const targetUser = state.users[target]
  if (targetUser) Object.assign(targetUser, data)
  return data
}

export async function adminStats() {
  const { data, error } = await supabase.rpc('admin_stats')
  if (error) throw fail(error)
  return data || {}
}

export async function setPrivacy(friendVerify, allowStrangerMoments) {
  const { data, error } = await supabase.rpc('set_privacy', {
    p_friend_verify: Boolean(friendVerify),
    p_allow_stranger_moments: Boolean(allowStrangerMoments)
  })
  if (error) throw fail(error)
  state.settings.friendVerify = Boolean(friendVerify)
  state.settings.allowStrangerMoments = Boolean(allowStrangerMoments)
  if (state.me) {
    state.me.friend_verify = Boolean(friendVerify)
    state.me.allow_stranger_moments = Boolean(allowStrangerMoments)
    cacheUser(state.me)
  }
  return data
}

/* ---------------- 实时 + 轮询 ---------------- */

let channel = null
let realtimeOk = false
let refreshTimer = null
let pollTimer = null

function debounceRefresh() {
  clearTimeout(refreshTimer)
  refreshTimer = setTimeout(() => refresh().catch(() => {}), 400)
}

function mapRow(row) {
  return {
    id: row.id,
    chatId: row.chat_id,
    fromId: row.from_id,
    type: row.type,
    content: row.content,
    duration: row.duration,
    recalled: row.recalled,
    at: row.at
  }
}

function onRealtimeMessage(row) {
  const message = mapRow(row)
  const chat = chatById(message.chatId)
  if (!chat) {
    debounceRefresh()
    return
  }
  ensureUser(message.fromId)
  addLocalMessage(message.chatId, message)
  touchChat(message.chatId, message)
  if (message.fromId !== state.me?.id) {
    if (state.activeChatId === message.chatId) {
      markRead(message.chatId)
    } else {
      chat.unread = (chat.unread || 0) + 1
    }
  }
}

function onRealtimeUpdate(row) {
  const message = mapRow(row)
  const list = state.messages[message.chatId]
  if (list) {
    const local = list.find(m => m.id === message.id)
    if (local) Object.assign(local, message)
  }
  const chat = chatById(message.chatId)
  if (chat) touchChat(message.chatId, message)
}

function onRealtimeDelete(old) {
  const id = old && old.id
  if (!id) return
  Object.keys(state.messages).forEach(chatId => {
    const list = state.messages[chatId]
    const i = list.findIndex(m => m.id === id)
    if (i > -1) list.splice(i, 1)
  })
  debounceRefresh()
}

function startRealtime() {
  if (channel) return
  channel = supabase
    .channel('liguang-realtime')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, p => onRealtimeMessage(p.new))
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, p => onRealtimeUpdate(p.new))
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, p => onRealtimeDelete(p.old))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'friend_requests' }, () => debounceRefresh())
    .on('postgres_changes', { event: '*', schema: 'public', table: 'moments' }, () => loadMoments().catch(() => {}))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'moment_likes' }, () => loadMoments().catch(() => {}))
    .on('postgres_changes', { event: '*', schema: 'public', table: 'moment_comments' }, () => loadMoments().catch(() => {}))
    .subscribe(status => {
      realtimeOk = status === 'SUBSCRIBED'
      if (!realtimeOk) console.warn('realtime status:', status)
    })
}

function stopRealtime() {
  if (channel) {
    supabase.removeChannel(channel)
    channel = null
  }
  realtimeOk = false
}

function startPolling() {
  stopPolling()
  pollTimer = setInterval(async () => {
    if (!state.me) return
    if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return
    try {
      await refresh()
      if (!realtimeOk && state.activeChatId) {
        await loadMessages(state.activeChatId)
      }
    } catch (e) {
      /* 忽略轮询失败 */
    }
  }, realtimeOk ? 45000 : 20000)
}

function stopPolling() {
  if (pollTimer) {
    clearInterval(pollTimer)
    pollTimer = null
  }
}

/* ---------------- 时间与数字 ---------------- */

function pad(n) {
  return n < 10 ? '0' + n : String(n)
}

export function formatTime(ms) {
  if (!ms) return ''
  const d = new Date(ms)
  const today = new Date()
  const isSameDay = (a, b) =>
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()

  if (isSameDay(d, today)) return pad(d.getHours()) + ':' + pad(d.getMinutes())

  const yest = new Date(today)
  yest.setDate(today.getDate() - 1)
  if (isSameDay(d, yest)) return '昨天 ' + pad(d.getHours()) + ':' + pad(d.getMinutes())

  if (d.getFullYear() === today.getFullYear()) {
    return pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes())
  }
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
}

export function formatDay(ms) {
  const d = new Date(ms)
  const today = new Date()
  const isSameDay = (a, b) =>
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  if (isSameDay(d, today)) return '今天'
  const yest = new Date(today)
  yest.setDate(today.getDate() - 1)
  if (isSameDay(d, yest)) return '昨天'
  return d.getMonth() + 1 + '月' + d.getDate() + '日'
}

export function formatCount(n) {
  if (n >= 10000) return (n / 10000).toFixed(1).replace('.0', '') + '万'
  return String(n)
}
