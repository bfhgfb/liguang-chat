<template>
  <div class="page login-page">
    <div class="login-inner">
      <img class="login-logo" :src="logoUrl" alt="小杜" />
      <h1 class="login-title">小杜</h1>

      <div class="login-tabs">
        <button :class="{ on: mode === 'login' }" @click="switchMode('login')">登录</button>
        <button :class="{ on: mode === 'register' }" @click="switchMode('register')">注册</button>
      </div>

      <div class="login-field">
        <label>账号</label>
        <input v-model="username" autocomplete="username" placeholder="3-20 位字母或数字" maxlength="20" />
      </div>

      <div v-if="mode === 'register'" class="login-field">
        <label>昵称</label>
        <input v-model="nickname" placeholder="别人看到的名字" maxlength="16" />
      </div>

      <div class="login-field">
        <label>密码</label>
        <input
          v-model="password"
          type="password"
          autocomplete="current-password"
          placeholder="至少 6 位"
          maxlength="32"
          @keyup.enter="submit"
        />
      </div>

      <div v-if="error" class="login-error">{{ error }}</div>
      <div v-if="retryHint" class="login-retry">{{ retryHint }}</div>

      <button class="login-btn" :disabled="loading" @click="submit">
        {{ loadingText }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { state, login, register } from '../store'
import { toast } from '../toast'

const router = useRouter()
const logoUrl = './icons/login-avatar.png'
const mode = ref('login')
const username = ref('')
const nickname = ref('')
const password = ref('')
const error = ref('')
const loading = ref(false)

const retryHint = computed(() =>
  loading.value && state.authRetry > 0
    ? `网络不太稳定，正在自动重试（第 ${state.authRetry} 次）…`
    : ''
)

const loadingText = computed(() => {
  if (!loading.value) return mode.value === 'login' ? '登录' : '注册并进入'
  return state.authRetry > 0 ? '网络较差，正在重试…' : '请稍候…'
})

onMounted(() => {
  if (state.kickedMsg) {
    error.value = state.kickedMsg
    state.kickedMsg = ''
  }
})

function switchMode(next) {
  mode.value = next
  error.value = ''
}

async function submit() {
  error.value = ''
  if (loading.value) return
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    error.value = '当前没有网络连接，请打开 Wi-Fi 或流量后再试'
    return
  }
  const name = username.value.trim()
  const pwd = password.value
  if (!name || !pwd) {
    error.value = '请填写账号和密码'
    return
  }
  if (pwd.length < 6) {
    error.value = '密码至少 6 位'
    return
  }
  if (mode.value === 'register' && !nickname.value.trim()) {
    error.value = '请填写昵称'
    return
  }
  loading.value = true
  try {
    if (mode.value === 'login') {
      await login(name, pwd)
      toast('欢迎回来')
    } else {
      await register(name, pwd, nickname.value.trim())
      toast('注册成功，欢迎使用')
    }
    router.replace('/chats')
  } catch (e) {
    error.value = e.message || '操作失败，请重试'
  } finally {
    loading.value = false
  }
}
</script>
