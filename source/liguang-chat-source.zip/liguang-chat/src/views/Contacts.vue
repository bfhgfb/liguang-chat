<template>
  <div class="page">
    <TopBar title="联系人" left>
      <template #right>
        <button class="icon-btn" aria-label="添加好友" @click="$router.push('/add-friend')">
          <Icon name="plus" :size="24" />
        </button>
      </template>
    </TopBar>

    <div class="search-wrap">
      <div class="search-box">
        <Icon name="search" :size="17" />
        <input v-model="keyword" placeholder="搜索联系人" />
      </div>
    </div>

    <div class="scroll">
      <div class="list" style="margin-bottom: 10px">
        <div class="row" @click="$router.push('/requests')">
          <Avatar id="LG-NEW" name="新" :size="46" />
          <div class="row-main">
            <div class="row-title">
              <span class="name">新的朋友</span>
            </div>
            <div class="row-desc">查看好友申请与验证消息</div>
          </div>
          <div class="row-side">
            <span v-if="pendingRequests.length" class="badge">{{ pendingRequests.length }}</span>
          </div>
        </div>
      </div>

      <div v-if="filteredFriends.length" class="list">
        <div class="section-label">我的好友（{{ friendList.length }}）</div>
        <template v-for="(friend, index) in filteredFriends" :key="friend.id">
          <div class="row" style="min-height: 60px" @click="$router.push('/profile/' + friend.id)">
            <Avatar :id="friend.id" :name="displayName(friend)" :size="44" />
            <div class="row-main">
              <div class="row-title">
                <span class="name">{{ displayName(friend) }}</span>
                <span v-if="friend.is_official" class="official-badge">官方</span>
              </div>
              <div class="row-desc">{{ friend.signature || '这个人很懒，什么都没写' }}</div>
            </div>
            <div class="row-side" style="align-self: center; padding-top: 0">
              <Icon name="chevron" :size="16" />
            </div>
          </div>
          <div v-if="index < filteredFriends.length - 1" class="divider" />
        </template>
      </div>

      <div v-else class="empty">
        <div class="empty-icon"><Icon name="contacts" :size="30" /></div>
        <div class="empty-title">{{ keyword ? '没有找到联系人' : '还没有好友' }}</div>
        <div class="empty-text">{{ keyword ? '换个关键词试试' : '添加好友后，就可以开始聊天了' }}</div>
        <button v-if="!keyword" class="empty-btn" @click="$router.push('/add-friend')">添加好友</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import { displayName, friendList, pendingRequests } from '../store'

const keyword = ref('')

const filteredFriends = computed(() => {
  const kw = keyword.value.trim().toLowerCase()
  if (!kw) return friendList.value
  return friendList.value.filter(
    f =>
      displayName(f).toLowerCase().includes(kw) ||
      (f.nickname || '').toLowerCase().includes(kw) ||
      f.id.toLowerCase().includes(kw)
  )
})
</script>
