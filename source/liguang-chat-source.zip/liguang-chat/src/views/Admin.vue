﻿<template>
  <div class="page">
    <TopBar title="用户管理" back />

    <div class="search-wrap">
      <div class="search-box">
        <Icon name="search" :size="17" />
        <input v-model="keyword" placeholder="搜索账号或昵称" />
      </div>
    </div>

    <div class="scroll">
      <div class="admin-stat">
        <div v-for="s in statItems" :key="s.label" class="stat-item">
          <div class="stat-num" :style="s.color ? { color: s.color } : {}">{{ s.value }}</div>
          <div class="stat-label">{{ s.label }}</div>
        </div>
      </div>

      <div v-if="loading" class="empty">
        <div class="empty-title">加载中…</div>
      </div>

      <div v-else-if="!filtered.length" class="empty">
        <div class="empty-icon"><Icon name="me" :size="30" /></div>
        <div class="empty-title">没有匹配的用户</div>
      </div>

      <div v-else class="admin-list">
        <div v-for="u in filtered" :key="u.id" class="admin-row">
          <Avatar :id="u.id" :name="u.nickname" :size="44" />
          <div class="admin-main">
            <div class="admin-name">
              <span>{{ u.nickname || u.username }}</span>
              <span v-if="u.is_official" class="official-badge">官方</span>
              <span v-if="u.disabled" class="status-off">已停用</span>
            </div>
            <div class="admin-meta">@{{ u.username }} · {{ formatDate(u.created_at) }}</div>
          </div>
          <div class="admin-actions">
            <button
              v-if="!u.is_official"
              class="admin-btn"
              :class="{ danger: !u.disabled }"
              :disabled="busyId === u.id"
              @click="toggle(u)"
            >
              {{ u.disabled ? '恢复' : '停用' }}
            </button>
            <button class="admin-btn" @click="openEdit(u)">编辑</button>
          </div>
        </div>
      </div>

      <div class="admin-tip">
        停用后，该账号下次进入应用会被强制退出并无法登录；编辑可修改昵称、简介与头像。
      </div>
    </div>

    <!-- 编辑用户弹窗 -->
    <Teleport to="body">
      <template v-if="editing">
        <div class="mask" @click="closeEdit" />
        <div class="admin-edit-sheet">
          <div class="ae-head">
            <div class="ae-title">编辑 @{{ editing.username }}</div>
            <button class="ae-close" @click="closeEdit">×</button>
          </div>
          <div class="ae-avatar">
            <Avatar :id="editing.id" :src="editForm.avatar_url || undefined" :name="editForm.nickname || editing.nickname" :size="64" />
            <button class="ae-upload" :disabled="uploading" @click="pickAvatar">
              {{ uploading ? '上传中…' : '更换头像' }}
            </button>
            <input ref="avatarRef" type="file" accept="image/*" style="display: none" @change="onAvatar" />
          </div>
          <div class="ae-field">
            <span class="ae-label">昵称</span>
            <input v-model="editForm.nickname" class="ae-input" maxlength="24" placeholder="昵称" />
          </div>
          <div class="ae-field">
            <span class="ae-label">简介</span>
            <input v-model="editForm.bio" class="ae-input" maxlength="60" placeholder="简介" />
          </div>
          <button class="ae-save" :disabled="saving || uploading" @click="saveEdit">
            {{ saving ? '保存中…' : '保存修改' }}
          </button>
        </div>
      </template>
    </Teleport>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import {
  state,
  adminListUsers,
  adminSetDisabled,
  adminStats,
  adminUpdateProfile,
  uploadDataUrl
} from '../store'
import { toast } from '../toast'
import { confirmDialog } from '../confirm'
import { fileToImage } from '../utils'

const router = useRouter()
const users = ref([])
const keyword = ref('')
const loading = ref(true)
const busyId = ref('')
const stats = ref(null)
const editing = ref(null)
const editForm = ref({ nickname: '', bio: '', avatar_url: '' })
const saving = ref(false)
const uploading = ref(false)
const avatarRef = ref(null)

const disabledCount = computed(() => users.value.filter(u => u.disabled).length)
const officialCount = computed(() => users.value.filter(u => u.is_official).length)
const filtered = computed(() => {
  const kw = keyword.value.trim().toLowerCase()
  if (!kw) return users.value
  return users.value.filter(
    u => (u.username || '').toLowerCase().includes(kw) || (u.nickname || '').toLowerCase().includes(kw)
  )
})
const statItems = computed(() => {
  const s = stats.value
  return [
    { label: '注册用户', value: s ? s.users : users.value.length },
    { label: '已停用', value: s ? s.disabled : disabledCount.value, color: '#ff3b30' },
    { label: '官方账号', value: s ? s.official : officialCount.value, color: '#f6c453' },
    { label: '动态总数', value: s ? s.moments : '—' },
    { label: '评论总数', value: s ? s.comments : '—' },
    { label: '点赞总数', value: s ? s.likes : '—' },
    { label: '聊天消息', value: s ? s.messages : '—' },
    { label: '会话总数', value: s ? s.chats : '—' },
    { label: '近7日新增', value: s ? s.new7d : '—', color: '#2e6be6' }
  ]
})

function formatDate(ms) {
  if (!ms) return ''
  const d = new Date(Number(ms))
  return `${d.getMonth() + 1}月${d.getDate()}日`
}

async function load() {
  loading.value = true
  try {
    users.value = await adminListUsers()
  } catch (e) {
    toast(e.message || '加载失败')
    router.replace('/me')
  } finally {
    loading.value = false
  }
  try {
    stats.value = await adminStats()
  } catch (e) {
    stats.value = null
  }
}

async function toggle(u) {
  const action = u.disabled ? '恢复' : '停用'
  if (!(await confirmDialog(`确定${action}账号 @${u.username} 吗？`, { danger: action === '停用' }))) return
  busyId.value = u.id
  try {
    await adminSetDisabled(u.id, !u.disabled)
    u.disabled = !u.disabled
    toast(`已${action} @${u.username}`)
  } catch (e) {
    toast(e.message || '操作失败')
  } finally {
    busyId.value = ''
  }
}

function openEdit(u) {
  editing.value = u
  editForm.value = {
    nickname: u.nickname || '',
    bio: u.bio || '',
    avatar_url: u.avatar_url || ''
  }
}

function closeEdit() {
  editing.value = null
}

function pickAvatar() {
  if (uploading.value) return
  avatarRef.value && avatarRef.value.click()
}

async function onAvatar(e) {
  const file = e.target.files && e.target.files[0]
  e.target.value = ''
  if (!file) return
  uploading.value = true
  try {
    const dataUrl = await fileToImage(file, 480, 0.8)
    const url = await uploadDataUrl(dataUrl)
    editForm.value.avatar_url = url
    toast('头像已准备，保存后生效')
  } catch (err) {
    toast(err.message || '头像上传失败')
  } finally {
    uploading.value = false
  }
}

async function saveEdit() {
  if (!editing.value || saving.value) return
  if (!editForm.value.nickname.trim()) {
    toast('昵称不能为空')
    return
  }
  saving.value = true
  try {
    const updated = await adminUpdateProfile(editing.value.id, {
      nickname: editForm.value.nickname.trim(),
      bio: editForm.value.bio.trim(),
      avatar_url: editForm.value.avatar_url
    })
    const row = users.value.find(u => u.id === updated.id)
    if (row) Object.assign(row, updated)
    if (editing.value) Object.assign(editing.value, updated)
    closeEdit()
    toast('资料已修改')
  } catch (e) {
    toast(e.message || '修改失败')
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  if (!state.me || !state.me.is_official) {
    toast('仅官方账号可访问')
    router.replace('/me')
    return
  }
  load()
})
</script>

<style scoped>
.admin-stat {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  padding: 14px 16px 6px;
}
.stat-item {
  background: #fff;
  border-radius: 14px;
  padding: 12px 8px;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}
.stat-num {
  font-size: 20px;
  font-weight: 800;
}
.stat-label {
  margin-top: 2px;
  font-size: 11.5px;
  color: #8b8b93;
}
.admin-list {
  background: #fff;
  margin: 10px 12px 0;
  border-radius: 14px;
  overflow: hidden;
}
.admin-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 11px 14px;
  border-bottom: 1px solid #f1f1f4;
}
.admin-row:last-child {
  border-bottom: none;
}
.admin-main {
  flex: 1;
  min-width: 0;
}
.admin-name {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 15px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.admin-meta {
  margin-top: 3px;
  font-size: 12px;
  color: #9a9aa2;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.official-badge {
  flex: none;
  font-size: 10px;
  font-weight: 800;
  color: #6b4a00;
  background: linear-gradient(135deg, #ffe9a8, #f6c453);
  border-radius: 5px;
  padding: 1px 5px;
}
.status-off {
  flex: none;
  font-size: 10px;
  font-weight: 700;
  color: #ff3b30;
  background: #ffeceb;
  border-radius: 5px;
  padding: 1px 5px;
}
.admin-btn {
  flex: none;
  border: none;
  border-radius: 8px;
  padding: 7px 12px;
  font-size: 12.5px;
  font-weight: 700;
  background: #f1f1f4;
  color: #333;
}
.admin-btn.danger {
  background: #ffeceb;
  color: #ff3b30;
}
.admin-actions {
  flex: none;
  display: flex;
  gap: 6px;
}
.admin-tip {
  padding: 14px 20px 28px;
  font-size: 11.5px;
  line-height: 1.6;
  color: #a0a0a8;
}
.admin-edit-sheet {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 60;
  background: #fff;
  border-radius: 18px 18px 0 0;
  padding: 18px 18px calc(20px + env(safe-area-inset-bottom));
  animation: sheetUp2 .2s ease both;
}
.ae-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
}
.ae-title {
  font-size: 16px;
  font-weight: 700;
}
.ae-close {
  border: none;
  background: #f1f1f4;
  border-radius: 50%;
  width: 28px;
  height: 28px;
  font-size: 18px;
  line-height: 1;
  color: #6b6b74;
}
.ae-avatar {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 6px 0 16px;
}
.ae-upload {
  font-size: 13px;
  color: var(--accent, #2e6be6);
}
.ae-field {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 2px;
  border-top: 1px solid #f0f0f3;
}
.ae-label {
  flex: none;
  width: 42px;
  font-size: 13.5px;
  color: #8b8b93;
}
.ae-input {
  flex: 1;
  min-width: 0;
  border: none;
  outline: none;
  font-size: 15px;
  background: transparent;
}
.ae-save {
  display: block;
  width: 100%;
  margin-top: 18px;
  height: 46px;
  border: none;
  border-radius: 12px;
  font-size: 15.5px;
  font-weight: 700;
  color: #232300;
  background: var(--accent, #ffd60a);
}
.ae-save:disabled {
  opacity: 0.55;
}
</style>
