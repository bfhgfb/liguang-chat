<template>
  <div class="page">
    <TopBar title="我" left />

    <div class="scroll">
      <template v-if="me">
        <div class="profile-hero" @click="$router.push('/profile/' + me.id)">
          <Avatar :id="me.id" :name="me.nickname" :size="62" />
          <div class="info">
            <div class="nickname">
              {{ me.nickname }}
              <span v-if="me.is_official" class="official-badge">官方</span>
            </div>
            <div class="uid">@{{ me.username }}</div>
            <div class="signature">{{ me.bio || '这个人很懒，什么都没写' }}</div>
          </div>
          <Icon name="chevron" :size="18" style="color: #c5c5cc" />
        </div>

        <div class="section-gap" />

        <div class="menu-group">
          <div class="menu-item" @click="$router.push('/moments')">
            <span class="menu-icon" style="background: #ff9f0a"><Icon name="compass" :size="17" /></span>
            <span class="menu-label">我的动态</span>
            <Icon name="chevron" :size="15" style="color: #c9c9d2" />
          </div>
          <div class="menu-item" @click="qrVisible = true">
            <span class="menu-icon" style="background: #2e6be6"><Icon name="qr" :size="17" /></span>
            <span class="menu-label">我的二维码</span>
            <Icon name="chevron" :size="15" style="color: #c9c9d2" />
          </div>
          <div class="menu-item" @click="$router.push('/profile-edit')">
            <span class="menu-icon" style="background: #ff9500"><Icon name="me" :size="17" /></span>
            <span class="menu-label">编辑资料</span>
            <Icon name="chevron" :size="15" style="color: #c9c9d2" />
          </div>
          <div v-if="me.is_official" class="menu-item" @click="$router.push('/admin')">
            <span class="menu-icon" style="background: #1c1c1e"><Icon name="shield" :size="17" /></span>
            <span class="menu-label">用户管理</span>
            <span class="menu-value" style="color: #f6c453; font-weight: 700">官方</span>
            <Icon name="chevron" :size="15" style="color: #c9c9d2" />
          </div>
          <div class="menu-item" @click="$router.push('/settings')">
            <span class="menu-icon" style="background: #34c759"><Icon name="settings" :size="17" /></span>
            <span class="menu-label">设置</span>
            <Icon name="chevron" :size="15" style="color: #c9c9d2" />
          </div>
        </div>

        <div class="section-gap" />

        <div class="menu-group">
          <div class="menu-item" @click="openLegal('service')">
            <span class="menu-icon" style="background: #8e8e93"><Icon name="shield" :size="17" /></span>
            <span class="menu-label">服务协议</span>
            <Icon name="chevron" :size="15" style="color: #c9c9d2" />
          </div>
          <div class="menu-item" @click="openLegal('privacy')">
            <span class="menu-icon" style="background: #8e8e93"><Icon name="lock" :size="17" /></span>
            <span class="menu-label">隐私协议</span>
            <Icon name="chevron" :size="15" style="color: #c9c9d2" />
          </div>
          <div class="menu-item" @click="toast('小杜 v1.0.7 · 1101')">
            <span class="menu-icon" style="background: #8e8e93"><Icon name="info" :size="17" /></span>
            <span class="menu-label">关于小杜</span>
            <span class="menu-value">v1.0.7 · 1101</span>
          </div>
        </div>

        <div class="section-gap" />

        <div class="menu-group">
          <div class="menu-item danger" @click="signOut">
            <span class="menu-label">退出登录</span>
            <Icon name="logout" :size="18" style="color: #c9c9d2" />
          </div>
        </div>

        <div style="height: 28px" />
      </template>

      <div v-else class="empty" style="padding-top: 90px">
        <div class="empty-icon"><Icon name="me" :size="30" /></div>
        <div class="empty-title">正在加载</div>
        <div class="empty-text">请稍候…</div>
      </div>
    </div>

    <Teleport to="body">
      <div v-if="qrVisible && me" class="qr-mask" @click.self="qrVisible = false">
        <div class="qr-card">
          <div class="qr-title">我的二维码</div>
          <img v-if="qrSrc" :src="qrSrc" class="qr-img" alt="我的二维码" />
          <div class="qr-tip">{{ me.nickname }} · @{{ me.username }}</div>
          <div class="qr-tip" style="color: #a3a3ab">扫一扫加我为好友</div>
          <button class="qr-close" @click="qrVisible = false">关闭</button>
        </div>
      </div>
    </Teleport>

    <LegalSheet :visible="legalVisible" :type="legalType" @close="legalVisible = false" />
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import LegalSheet from '../components/LegalSheet.vue'
import { state, logout, profileLink } from '../store'
import qrcode from 'qrcode-generator'
import { toast } from '../toast'
import { confirmDialog } from '../confirm'

const router = useRouter()
const me = computed(() => state.me)
const qrVisible = ref(false)
const legalVisible = ref(false)
const legalType = ref('service')

const qrSrc = computed(() => {
  if (!me.value) return ''
  const qr = qrcode(0, 'M')
  qr.addData(profileLink(me.value.username))
  qr.make()
  return qr.createDataURL(8, 0)
})

function openLegal(type) {
  legalType.value = type
  legalVisible.value = true
}

async function signOut() {
  if (!(await confirmDialog('确定退出当前账号？', { danger: true }))) return
  logout()
  toast('已退出登录')
  router.replace('/login')
}
</script>
