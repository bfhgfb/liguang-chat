<template>
  <div class="page">
    <TopBar title="详细资料" back />

    <div class="scroll">
      <template v-if="user">
        <div class="detail-hero">
          <Avatar :id="user.id" :name="displayName(user)" :size="72" />
          <div class="info" style="flex: 1; min-width: 0">
            <div style="font-size: 22px; font-weight: 700">
              {{ displayName(user) }}
              <span v-if="user.is_official" class="official-badge">官方</span>
              <span v-if="user.disabled" class="status-off">已停用</span>
            </div>
            <div v-if="remark" style="margin-top: 4px; font-size: 13px; color: #8b8b93">
              昵称 {{ user.nickname }}
            </div>
            <div class="uid" style="margin-top: 6px; font-size: 12.5px; color: #8b8b93; font-family: ui-monospace, Menlo, monospace">
              @{{ user.username }}
            </div>
            <div style="margin-top: 6px; font-size: 13px; color: #8b8b93">
              {{ user.region || '未填写地区' }}
            </div>
          </div>
        </div>

        <div class="divider-full" />

        <div class="menu-group">
          <div v-if="!isMe && isFriend(user.id)" class="menu-item" @click="editRemark">
            <span class="menu-label" style="color: #8b8b93; font-size: 13px">备注</span>
            <span class="menu-value" style="max-width: 60%; text-align: right">{{ remark || '未设置' }}</span>
          </div>
          <div class="menu-item">
            <span class="menu-label" style="color: #8b8b93; font-size: 13px">个性签名</span>
            <span class="menu-value" style="max-width: 60%; text-align: right">{{ user.bio || '这个人很懒，什么都没写' }}</span>
          </div>
          <div class="menu-item">
            <span class="menu-label" style="color: #8b8b93; font-size: 13px">账号</span>
            <span class="menu-value" style="font-family: ui-monospace, Menlo, monospace">@{{ user.username }}</span>
          </div>
        </div>

        <div class="detail-actions">
          <template v-if="isMe">
            <button class="action-btn primary" @click="router.push('/profile-edit')">编辑资料</button>
          </template>
          <template v-else-if="isFriend(user.id)">
            <button class="action-btn primary" :disabled="opening" @click="sendMessage">
              {{ opening ? '打开会话…' : '发消息' }}
            </button>
            <button class="action-btn" @click="toggleBlock">{{ isBlocked(user.id) ? '移出黑名单' : '加入黑名单' }}</button>
            <button class="action-btn danger" @click="remove">删除好友</button>
          </template>
          <template v-else>
            <div class="empty-text" style="text-align: center; font-size: 13px; color: #8b8b93; padding: 4px 18px 8px">
              你们还不是好友，添加后可开始聊天
            </div>
            <button class="action-btn primary" @click="$router.push('/add-friend')">添加好友</button>
          </template>
          <button
            v-if="canModerate"
            class="action-btn danger"
            :disabled="moderating"
            @click="toggleDisabled"
          >
            {{ moderating ? '处理中…' : user.disabled ? '恢复该账号' : '停用该账号' }}
          </button>
        </div>
      </template>

      <div v-else class="empty">
        <div class="empty-icon"><Icon name="me" :size="30" /></div>
        <div class="empty-title">用户不存在</div>
        <div class="empty-text">该用户可能已注销或 ID 输入有误</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import {
  state,
  userById,
  isFriend,
  isBlocked,
  isOfficial,
  displayName,
  setFriendRemark,
  openDirect,
  removeFriend,
  blockUser,
  unblockUser,
  adminSetDisabled
} from '../store'
import { toast } from '../toast'
import { confirmDialog } from '../confirm'
import { promptDialog } from '../prompt'

const route = useRoute()
const router = useRouter()
const id = computed(() => String(route.params.id))
const user = computed(() => userById(id.value))
const isMe = computed(() => id.value === state.me?.id)
const remark = computed(() => state.remarks[id.value] || '')
const opening = ref(false)

async function editRemark() {
  if (!user.value) return
  const value = await promptDialog('设置备注', {
    value: remark.value,
    placeholder: '给对方起个好认的名字',
    maxlength: 24
  })
  if (value === null) return
  try {
    await setFriendRemark(user.value.id, value)
    toast(value.trim() ? '备注已保存' : '备注已清除')
  } catch (e) {
    toast(e.message || '备注保存失败')
  }
}
const moderating = ref(false)
const canModerate = computed(
  () => isOfficial() && Boolean(user.value) && !user.value.is_official && !isMe.value
)

async function toggleDisabled() {
  if (!user.value || moderating.value) return
  const action = user.value.disabled ? '恢复' : '停用'
  if (!(await confirmDialog(`确定${action}账号 @${user.value.username} 吗？`, { danger: action === '停用' }))) return
  moderating.value = true
  try {
    await adminSetDisabled(user.value.id, !user.value.disabled)
    toast(`已${action}该账号`)
  } catch (e) {
    toast(e.message || '操作失败')
  } finally {
    moderating.value = false
  }
}

async function sendMessage() {
  if (!user.value || opening.value) return
  opening.value = true
  try {
    const chat = await openDirect(user.value.id)
    router.push('/chat/' + chat.id)
  } catch (e) {
    toast(e.message || '打开会话失败')
  } finally {
    opening.value = false
  }
}

async function toggleBlock() {
  if (!user.value) return
  const target = user.value.id
  try {
    if (isBlocked(target)) {
      await unblockUser(target)
      toast('已移出黑名单')
    } else {
      await blockUser(target)
      toast('已加入黑名单')
    }
  } catch (e) {
    toast(e.message || '操作失败')
  }
}

async function remove() {
  if (!user.value) return
  if (!(await confirmDialog('删除好友后，聊天记录将一并清除，确定删除？', { danger: true }))) return
  try {
    await removeFriend(user.value.id)
    toast('已删除好友')
    router.replace('/contacts')
  } catch (e) {
    toast(e.message || '删除失败')
  }
}
</script>
