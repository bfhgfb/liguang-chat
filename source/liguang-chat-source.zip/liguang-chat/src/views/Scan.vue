<template>
  <div class="page scan-page">
    <TopBar title="扫一扫" back />

    <div class="scan-body">
      <div class="scan-frame">
        <video ref="videoRef" class="scan-video" playsinline muted />
        <div class="scan-box" />
        <div v-if="!cameraReady" class="scan-mask">
          <div class="scan-tip">{{ tip }}</div>
        </div>
      </div>

      <div class="scan-actions">
        <button class="scan-btn" :disabled="starting" @click="startCamera">
          {{ starting ? '启动中…' : '重新开启相机' }}
        </button>
        <button class="scan-btn ghost" @click="pickFile">从相册选择</button>
        <input ref="fileRef" type="file" accept="image/*" style="display: none" @change="onFile" />
      </div>

      <div class="scan-hint">将对方「我的二维码」放入框内，识别成功会自动跳转到添加好友。</div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, onUnmounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import jsQR from 'jsqr'
import { toast } from '../toast'

const router = useRouter()
const videoRef = ref(null)
const fileRef = ref(null)
const cameraReady = ref(false)
const starting = ref(false)
const tip = ref('正在启动相机…')

let stream = null
let timer = null
let canvas = null
let ctx = null
let done = false

function makeCanvas() {
  canvas = document.createElement('canvas')
  ctx = canvas.getContext('2d', { willReadFrequently: true })
}

async function startCamera() {
  if (starting.value || done) return
  starting.value = true
  stopCamera()
  tip.value = '正在启动相机…'
  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('当前环境不支持相机')
    }
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 1280 } }
    })
    const video = videoRef.value
    video.srcObject = stream
    await video.play().catch(() => {})
    cameraReady.value = true
    tip.value = ''
    if (!canvas) makeCanvas()
    tick()
  } catch (e) {
    cameraReady.value = false
    tip.value = '相机无法使用，请允许相机权限，或用「从相册选择」'
    console.warn('camera failed', e)
  } finally {
    starting.value = false
  }
}

function tick() {
  clearTimeout(timer)
  timer = setTimeout(scanFrame, 260)
}

function scanFrame() {
  if (done) return
  const video = videoRef.value
  if (video && video.readyState >= 2 && video.videoWidth) {
    const w = video.videoWidth
    const h = video.videoHeight
    const size = Math.min(w, h)
    const sx = (w - size) / 2
    const sy = (h - size) / 2
    canvas.width = 480
    canvas.height = 480
    ctx.drawImage(video, sx, sy, size, size, 0, 0, 480, 480)
    const data = ctx.getImageData(0, 0, 480, 480)
    const found = jsQR(data.data, 480, 480, { inversionAttempts: 'dontInvert' })
    if (found && found.data) {
      handleResult(found.data)
      return
    }
  }
  tick()
}

function stopCamera() {
  clearTimeout(timer)
  timer = null
  if (stream) {
    stream.getTracks().forEach(t => t.stop())
    stream = null
  }
}

function parseTarget(text) {
  const raw = String(text || '').trim()
  if (!raw) return ''
  let name = ''
  try {
    const url = new URL(raw)
    name = url.searchParams.get('u') || ''
    if (!name) {
      const m = url.pathname.match(/\/add\/([a-z0-9_-]+)/i) || url.hash.match(/u=([a-z0-9_-]+)/i)
      if (m) name = m[1]
    }
  } catch (e) {
    const m = raw.match(/u=([a-z0-9_-]+)/i) || raw.match(/xiaodu:\/\/u\/([a-z0-9_-]+)/i)
    if (m) name = m[1]
  }
  return name.trim().toLowerCase()
}

function handleResult(text) {
  const username = parseTarget(text)
  if (!username) {
    toast('这不是小杜的好友二维码')
    return
  }
  done = true
  stopCamera()
    router.replace('/add?u=' + encodeURIComponent(username))
}

function pickFile() {
  fileRef.value && fileRef.value.click()
}

function onFile(e) {
  const file = e.target.files && e.target.files[0]
  e.target.value = ''
  if (!file) return
  const img = new Image()
  const url = URL.createObjectURL(file)
  img.onload = () => {
    try {
      if (!canvas) makeCanvas()
      const max = 900
      const scale = Math.min(1, max / Math.max(img.width, img.height))
      canvas.width = Math.round(img.width * scale)
      canvas.height = Math.round(img.height * scale)
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height)
      const found = jsQR(data.data, canvas.width, canvas.height)
      if (found && found.data) handleResult(found.data)
      else toast('没有识别到二维码，换一张清晰点的图试试')
    } catch (err) {
      toast('图片识别失败')
    } finally {
      URL.revokeObjectURL(url)
    }
  }
  img.onerror = () => {
    URL.revokeObjectURL(url)
    toast('图片加载失败')
  }
  img.src = url
}

onMounted(() => {
  startCamera()
})

onUnmounted(() => {
  done = true
  stopCamera()
})
</script>

<style scoped>
.scan-page {
  background: #0d0d10;
}
.scan-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0 24px 40px;
  min-height: 0;
}
.scan-frame {
  position: relative;
  width: 100%;
  max-width: 340px;
  aspect-ratio: 1 / 1;
  border-radius: 18px;
  overflow: hidden;
  background: #000;
}
.scan-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.scan-box {
  position: absolute;
  left: 12%;
  top: 12%;
  width: 76%;
  height: 76%;
  border: 2px solid rgba(255, 255, 255, 0.85);
  border-radius: 14px;
  box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.28);
}
.scan-mask {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  text-align: center;
}
.scan-tip {
  font-size: 13px;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.78);
}
.scan-actions {
  display: flex;
  gap: 12px;
  margin-top: 22px;
}
.scan-btn {
  padding: 10px 18px;
  border-radius: 999px;
  font-size: 13.5px;
  color: #0d0d10;
  background: #fff;
  font-weight: 600;
}
.scan-btn.ghost {
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
}
.scan-btn:disabled {
  opacity: 0.6;
}
.scan-hint {
  margin-top: 20px;
  max-width: 300px;
  text-align: center;
  font-size: 12px;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.55);
}
</style>
