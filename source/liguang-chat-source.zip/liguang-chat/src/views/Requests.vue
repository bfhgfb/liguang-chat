<template>
  <div class="page">
    <TopBar title="新的朋友" back>
      <template #right>
        <button class="icon-btn" aria-label="添加好友" @click="$router.push('/add-friend')">
          <Icon name="plus" :size="24" />
        </button>
      </template>
    </TopBar>

    <div class="scroll">
      <div v-if="requests.length" class="list">
        <template v-for="(req, index) in requests" :key="req.id">
          <div class="req-row">
            <Avatar
              v-if="req.peer"
              :id="req.peer.id"
              :name="req.peer.nickname"
              :size="46"
            />
            <Avatar v-else id="LG-U" name="用" :size="46" />
            <div class="info">
              <div class="name">{{ req.peer?.nickname || '未知用户' }}</div>
              <div class="sub">{{ formatTime(req.createdAt || req.at) }} · {{ statusText(req) }}</div>
            </div>

            <template v-if="req.status === 'waiting' && req.direction === 'in'">
              <button class="accept" :disabled="busyId === req.id" @click="accept(req)">接受</button>
              <button class="accept ghost" :disabled="busyId === req.id" @click="reject(req)">忽略</button>
            </template>
            <span v-else class="state">{{ stateLabel(req) }}</span>
          </div>
          <div v-if="index < requests.length - 1" class="divider" />
        </template>
      </div>

      <div v-else class="empty">
        <div class="empty-icon"><Icon name="contacts" :size="30" /></div>
        <div class="empty-title">暂无好友申请</div>
        <div class="empty-text">去「添加好友」搜索对方 ID，发送好友请求</div>
        <button class="empty-btn" @click="$router.push('/add-friend')">添加好友</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import {
  state,
  formatTime,
  acceptRequest,
  rejectRequest,
  chatByPeer
} from '../store'
import { toast } from '../toast'

const router = useRouter()
const busyId = ref('')

const requests = computed(() =>
  [...state.requests].sort((a, b) => {
    const rank = s => (s === 'waiting' ? 0 : s === 'accepted' ? 1 : 2)
    return rank(a.status) - rank(b.status) || (b.createdAt || b.at) - (a.createdAt || a.at)
  })
)

function statusText(req) {
  if (req.status === 'accepted') return '已成为好友'
  if (req.status === 'rejected') return '已忽略'
  return req.direction === 'out' ? '你发送了好友请求' : '请求添加你为好友'
}

function stateLabel(req) {
  if (req.status === 'accepted') return '已添加'
  if (req.status === 'rejected') return '已忽略'
  return req.direction === 'out' ? '等待验证' : ''
}

async function accept(req) {
  busyId.value = req.id
  try {
    await acceptRequest(req.id)
    toast('已添加为好友')
    const chat = chatByPeer(req.peer?.id)
    if (chat) router.push('/chat/' + chat.id)
  } catch (e) {
    toast(e.message || '操作失败')
  } finally {
    busyId.value = ''
  }
}

async function reject(req) {
  busyId.value = req.id
  try {
    await rejectRequest(req.id)
    toast('已忽略')
  } catch (e) {
    toast(e.message || '操作失败')
  } finally {
    busyId.value = ''
  }
}
</script>

<style scoped>
.accept.ghost {
  background: #f2f2f6;
  color: #6f6f78;
  margin-left: 6px;
}
</style>
