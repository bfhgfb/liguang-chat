<template>
  <div class="page">
    <TopBar title="添加好友" back />

    <div class="scroll">
      <div class="add-hero">
        <div class="add-title">添加朋友</div>
        <div class="add-sub">输入对方的账号，或直接用「扫一扫」扫对方的二维码，找到后发送好友请求。</div>

        <div class="add-input-wrap">
          <input
            v-model="query"
            class="add-input"
            maxlength="20"
            placeholder="对方的账号，例如 @deployer"
            @input="onInput"
            @keyup.enter="search"
          />
          <button class="add-submit" :disabled="searching" @click="search">
            {{ searching ? '搜索中…' : '搜索' }}
          </button>
        </div>

        <div v-if="error" class="add-error">{{ error }}</div>
        <div class="add-hint">
          提示：账号就是对方注册时填的名字（「我」页面 @ 后面的那串），也可以点下方二维码让对方扫你。
        </div>
      </div>

      <div v-if="found" class="add-card">
        <Avatar :id="found.id" :name="found.nickname" :size="52" />
        <div class="info">
          <div class="name">{{ found.nickname }}</div>
          <div class="uid">@{{ found.username }}</div>
          <div class="status">{{ statusText }}</div>
          <button
            v-if="!isFriend(found.id) && !sent"
            class="mock-btn"
            style="background: var(--accent); color: #232300; font-weight: 700"
            :disabled="sending"
            @click="add"
          >
            {{ sending ? '发送中…' : '添加好友' }}
          </button>
          <button
            v-if="isFriend(found.id)"
            class="mock-btn"
            style="background: var(--accent); color: #232300; font-weight: 700"
            @click="openChat"
          >
            发消息
          </button>
        </div>
      </div>

      <div class="my-id-card">
        <Avatar :id="me?.id" :name="me?.nickname" :size="44" />
        <div style="min-width: 0">
          <div class="label">我的账号</div>
          <div class="value">@{{ me?.username }}</div>
        </div>
        <button class="copy" @click="copyId">复制</button>
      </div>

      <div class="my-id-card" style="cursor: pointer" @click="qrVisible = true">
        <div class="qr-mini">二维码</div>
        <div style="min-width: 0">
          <div class="label">我的二维码</div>
          <div class="value">让朋友扫一扫，直接加我</div>
        </div>
        <Icon name="chevron" :size="16" style="color: #c5c5cc" />
      </div>
    </div>

    <Teleport to="body">
      <div v-if="qrVisible && me" class="qr-mask" @click.self="qrVisible = false">
        <div class="qr-card">
          <div class="qr-title">我的二维码</div>
          <img v-if="qrSrc" :src="qrSrc" class="qr-img" alt="我的二维码" />
          <div class="qr-tip">{{ me.nickname }} · @{{ me.username }}</div>
          <div class="qr-tip" style="color: #a3a3ab">扫一扫加我为好友</div>
          <button class="qr-close" @click="qrVisible = false">关闭</button>
        </div>
      </div>
    </Teleport>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import {
  state,
  isFriend,
  searchUser,
  sendFriendRequest,
  openDirect,
  profileLink
} from '../store'
import { copyText } from '../utils'
import { toast } from '../toast'
import qrcode from 'qrcode-generator'

const route = useRoute()
const router = useRouter()
const me = computed(() => state.me)
const query = ref('')
const error = ref('')
const found = ref(null)
const sent = ref(false)
const searching = ref(false)
const sending = ref(false)
const qrVisible = ref(false)

const qrSrc = computed(() => {
  if (!me.value) return ''
  const qr = qrcode(0, 'M')
  qr.addData(profileLink(me.value.username))
  qr.make()
  return qr.createDataURL(8, 0)
})

const statusText = computed(() => {
  if (!found.value) return ''
  if (found.value.id === me.value?.id) return '这是你自己'
  if (isFriend(found.value.id)) return '你们已经是好友了'
  if (sent.value) return '好友请求已发送，等待对方同意'
  return '用户存在，可以发送好友请求'
})

function normalize(v) {
  return String(v || '')
    .trim()
    .replace(/^@/, '')
    .toLowerCase()
}

function onInput() {
  error.value = ''
  found.value = null
  sent.value = false
}

async function search() {
  const id = normalize(query.value)
  if (!id) {
    error.value = '请输入对方的账号'
    return null
  }
  searching.value = true
  error.value = ''
  try {
    const user = await searchUser(id)
    found.value = user
    if (!user) error.value = '账号不存在，请确认后重试'
    return user
  } catch (e) {
    error.value = e.message || '搜索失败'
    return null
  } finally {
    searching.value = false
  }
}

async function add() {
  if (!found.value) return
  sending.value = true
  try {
    const res = await sendFriendRequest(found.value.id)
    sent.value = true
    if (res && res.status === 'accepted') toast('对方没开启验证，已直接成为好友')
    else toast('好友请求已发送')
  } catch (e) {
    error.value = e.message || '发送失败'
  } finally {
    sending.value = false
  }
}

async function openChat() {
  if (!found.value) return
  try {
    const chat = await openDirect(found.value.id)
    router.push('/chat/' + chat.id)
  } catch (e) {
    toast(e.message || '打开会话失败')
  }
}

async function copyId() {
  if (!me.value) return
  const ok = await copyText('@' + me.value.username)
  toast(ok ? '账号已复制' : '复制失败，请手动记录')
}

async function autoAdd(username) {
  query.value = '@' + username
  const user = await search()
  if (!user || user.id === me.value?.id) return
  if (isFriend(user.id)) {
    toast('你们已经是好友了')
    return
  }
  if (!user) return
  await add()
}

onMounted(() => {
  const u = route.query.u
  if (u) autoAdd(normalize(u))
})
</script>

<style scoped>
.qr-mini {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  background: #2e6be6;
  color: #fff;
  font-size: 12.5px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: none;
}
</style>
