<template>
  <div class="page">
    <TopBar title="设置" back />

    <div class="scroll">
      <div class="section-label">隐私</div>
      <div class="menu-group">
        <div class="menu-item">
          <span class="menu-label">加我为好友时需要验证</span>
          <button
            class="switch"
            :class="{ on: state.settings.friendVerify }"
            :disabled="busy"
            aria-label="切换好友验证"
            @click="toggle"
          />
        </div>
      </div>

      <div class="section-label">黑名单</div>
      <div class="menu-group">
        <div v-if="!blockedUsers.length" class="menu-item">
          <span class="menu-label" style="color: #a3a3ad">暂无拉黑用户</span>
        </div>
        <div v-for="u in blockedUsers" :key="u.id" class="menu-item">
          <div class="blocked-user">
            <Avatar :id="u.id" :name="u.nickname || u.username" :size="34" />
            <span class="menu-label">{{ u.nickname || u.username }}</span>
          </div>
          <button class="unblock-btn" :disabled="busyId === u.id" @click="unblock(u)">
            {{ busyId === u.id ? '处理中…' : '解除' }}
          </button>
        </div>
      </div>

      <div class="section-label">协议与条款</div>
      <div class="menu-group">
        <div class="menu-item" @click="openLegal('service')">
          <span class="menu-label">小杜服务协议</span>
          <Icon name="chevron" :size="15" style="color: #c9c9d2" />
        </div>
        <div class="menu-item" @click="openLegal('privacy')">
          <span class="menu-label">小杜隐私协议</span>
          <Icon name="chevron" :size="15" style="color: #c9c9d2" />
        </div>
      </div>

      <div class="section-label">通用</div>
      <div class="menu-group">
        <div class="menu-item">
          <span class="menu-label">当前版本</span>
          <span class="menu-value">v1.0.7 · 1101</span>
        </div>
        <div class="menu-item">
          <span class="menu-label">服务器</span>
          <span class="menu-value">{{ serverHost }}</span>
        </div>
      </div>

      <div class="section-label">账号</div>
      <div class="menu-group">
        <div class="menu-item danger" @click="signOut">
          <span class="menu-label">退出登录</span>
        </div>
      </div>

      <div style="padding: 26px 18px; text-align: center; font-size: 12px; color: #b0b0b8">
        小杜 · 账号与消息保存在 Supabase 云端
      </div>
    </div>

    <LegalSheet :visible="legalVisible" :type="legalType" @close="legalVisible = false" />
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import LegalSheet from '../components/LegalSheet.vue'
import { state, logout, setPrivacy, loadBlockedUsers, unblockUser } from '../store'
import { toast } from '../toast'
import { confirmDialog } from '../confirm'

const router = useRouter()
const legalVisible = ref(false)
const legalType = ref('service')
const busy = ref(false)
const blockedUsers = ref([])
const busyId = ref('')

onMounted(loadBlocked)

async function loadBlocked() {
  try {
    blockedUsers.value = await loadBlockedUsers()
  } catch (e) {
    blockedUsers.value = []
  }
}

async function unblock(u) {
  if (!(await confirmDialog(`确定把「${u.nickname || u.username}」移出黑名单？`))) return
  busyId.value = u.id
  try {
    await unblockUser(u.id)
    blockedUsers.value = blockedUsers.value.filter(x => x.id !== u.id)
    toast('已移出黑名单')
  } catch (e) {
    toast(e.message || '解除失败')
  } finally {
    busyId.value = ''
  }
}

async function toggle() {
  if (busy.value) return
  const prevVerify = state.settings.friendVerify
  const nextVerify = !prevVerify

  state.settings.friendVerify = nextVerify
  busy.value = true
  try {
    await setPrivacy(nextVerify, state.settings.allowStrangerMoments)
    toast(nextVerify ? '已开启好友验证' : '已关闭好友验证，添加直接通过')
  } catch (e) {
    state.settings.friendVerify = prevVerify
    toast(e.message || '保存失败')
  } finally {
    busy.value = false
  }
}

const serverHost = computed(() => {
  if (window.__API_BASE__) return window.__API_BASE__
  return location.host || '本机'
})

function openLegal(type) {
  legalType.value = type
  legalVisible.value = true
}

async function signOut() {
  if (!(await confirmDialog('确定退出当前账号？', { danger: true }))) return
  logout()
  toast('已退出登录')
  router.replace('/login')
}
</script>

<style scoped>
.blocked-user {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.blocked-user .menu-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.unblock-btn {
  flex: none;
  border: none;
  background: rgba(20, 20, 26, 0.06);
  color: #4a4a52;
  font-size: 13px;
  padding: 7px 14px;
  border-radius: 999px;
  cursor: pointer;
}
.unblock-btn:disabled {
  opacity: 0.55;
}
</style>
