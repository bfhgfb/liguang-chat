<template>
  <div class="page">
    <TopBar title="消息" left>
      <template #right>
        <button class="icon-btn" aria-label="更多" @click="sheetVisible = true">
          <Icon name="plus" :size="24" />
        </button>
      </template>
    </TopBar>

    <div class="search-wrap">
      <div class="search-box">
        <Icon name="search" :size="17" />
        <input v-model="keyword" placeholder="搜索聊天" />
        <button v-if="keyword" class="icon-btn" style="width: 24px; height: 24px" @click="keyword = ''">
          <Icon name="close" :size="15" />
        </button>
      </div>
    </div>

    <div class="scroll">
      <div v-if="filtered.length" class="list">
        <template v-for="(chat, index) in filtered" :key="chat.id">
          <div class="row" @click="openChat(chat)" @contextmenu.prevent="openChatMenu(chat)">
            <div style="position: relative; flex: none">
              <Avatar
                :id="chat.type === 'group' ? 'G' + chat.id : chat.peer?.id"
                :name="chat.type === 'group' ? chat.title : displayName(chat.peer)"
                :size="46"
              />
              <span
                v-if="chat.unread && !chat.muted"
                class="badge"
                style="position: absolute; top: -6px; right: -6px"
              >{{ chat.unread > 99 ? '99+' : chat.unread }}</span>
              <span
                v-if="chat.muted"
                class="muted-dot"
                style="position: absolute; right: -4px; bottom: -2px; background: #fff; border-radius: 50%; padding: 1px"
              >
                <Icon name="mute" :size="12" />
              </span>
            </div>

            <div class="row-main">
              <div class="row-title">
                <span class="name">{{ chat.title }}</span>
                <span v-if="chat.type === 'direct' && chat.peer?.is_official" class="official-badge">官方</span>
                <span v-if="chat.type === 'group'" class="group-tag">群</span>
              </div>
              <div class="row-desc">{{ chat.preview }}</div>
            </div>

            <div class="row-side">
              <div>{{ formatTime(chat.lastAt) }}</div>
              <div v-if="chat.pinned" style="margin-top: 6px; color: #c5c5cc">
                <Icon name="pin" :size="12" />
              </div>
            </div>
          </div>
          <div v-if="index < filtered.length - 1" class="divider" />
        </template>
      </div>

      <div v-else class="empty">
        <div class="empty-icon"><Icon name="chat" :size="30" /></div>
        <div class="empty-title">{{ keyword ? '没有找到相关聊天' : '还没有聊天' }}</div>
        <div class="empty-text">{{ keyword ? '换个关键词试试' : '去添加好友，开始第一段对话吧' }}</div>
        <button v-if="!keyword" class="empty-btn" @click="$router.push('/add-friend')">添加好友</button>
      </div>
    </div>

    <ActionSheet
      :visible="sheetVisible"
      :items="createItems"
      @select="onCreate"
      @close="sheetVisible = false"
    />

    <ActionSheet
      v-if="activeChat"
      :visible="chatMenuVisible"
      :title="activeChat.title"
      :items="chatMenuItems"
      @select="onChatMenu"
      @close="chatMenuVisible = false"
    />

    <div v-if="groupVisible" class="compose-mask" @click.self="groupVisible = false">
      <div class="compose-card">
        <div class="compose-title">发起群聊</div>
        <input v-model="groupName" class="compose-input" placeholder="群聊名称（1-20 字）" maxlength="20" />
        <div class="group-friends">
          <div
            v-for="friend in friendList"
            :key="friend.id"
            class="group-friend"
            @click="toggleMember(friend.id)"
          >
            <Avatar :id="friend.id" :name="displayName(friend)" :size="34" />
            <span class="g-name">{{ displayName(friend) }}</span>
            <span class="check" :class="{ on: members.includes(friend.id) }">
              <Icon v-if="members.includes(friend.id)" name="check" :size="13" />
            </span>
          </div>
          <div v-if="!friendList.length" class="empty-text" style="padding: 18px 0; text-align: center">
            还没有好友，先去添加好友
          </div>
        </div>
        <button class="publish-btn" :disabled="!canCreate || creating" @click="doCreateGroup">
          {{ creating ? '创建中…' : '创建群聊' }}
        </button>
        <button class="qr-close" @click="groupVisible = false">取消</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import ActionSheet from '../components/ActionSheet.vue'
import {
  chatList,
  friendList,
  displayName,
  formatTime,
  togglePin,
  toggleMute,
  createGroup
} from '../store'
import { toast } from '../toast'

const router = useRouter()
const keyword = ref('')
const sheetVisible = ref(false)
const chatMenuVisible = ref(false)
const activeChat = ref(null)

const groupVisible = ref(false)
const groupName = ref('')
const members = ref([])
const creating = ref(false)

const filtered = computed(() => {
  const kw = keyword.value.trim().toLowerCase()
  if (!kw) return chatList.value
  return chatList.value.filter(c => {
    const name = (c.title || '').toLowerCase()
    return name.includes(kw) || (c.preview || '').toLowerCase().includes(kw)
  })
})

const createItems = [
  { id: 'add', label: '添加朋友' },
  { id: 'group', label: '发起群聊' },
  { id: 'scan', label: '扫一扫' }
]

const chatMenuItems = computed(() => {
  const chat = activeChat.value
  if (!chat) return []
  return [
    { id: 'pin', label: chat.pinned ? '取消置顶' : '置顶该会话' },
    { id: 'mute', label: chat.muted ? '取消免打扰' : '消息免打扰' }
  ]
})

const canCreate = computed(() => Boolean(groupName.value.trim()) && members.value.length > 0)

function openChat(chat) {
  router.push('/chat/' + chat.id)
}

function openChatMenu(chat) {
  activeChat.value = chat
  chatMenuVisible.value = true
}

function onCreate(id) {
  if (id === 'add') router.push('/add-friend')
  else if (id === 'group') {
    groupName.value = ''
    members.value = []
    groupVisible.value = true
  } else if (id === 'scan') router.push('/scan')
}

function onChatMenu(id) {
  const chat = activeChat.value
  if (!chat) return
  if (id === 'pin') {
    togglePin(chat.id)
    toast(chat.pinned ? '已取消置顶' : '已置顶')
  } else if (id === 'mute') {
    toggleMute(chat.id)
    toast(chat.muted ? '已取消免打扰' : '已开启免打扰')
  }
}

function toggleMember(id) {
  const i = members.value.indexOf(id)
  if (i > -1) members.value.splice(i, 1)
  else members.value.push(id)
}

async function doCreateGroup() {
  if (!canCreate.value) return
  creating.value = true
  try {
    const chat = await createGroup(groupName.value.trim(), members.value)
    groupVisible.value = false
    toast('群聊已创建')
    router.push('/chat/' + chat.id)
  } catch (e) {
    toast(e.message || '创建失败')
  } finally {
    creating.value = false
  }
}
</script>
