<template>
  <div class="page">
    <TopBar title="动态" left>
      <template #right>
        <button class="icon-btn" aria-label="发布动态" @click="openCompose">
          <Icon name="edit" :size="22" />
        </button>
      </template>
    </TopBar>

    <div class="scroll" style="background: #fff">
      <div v-if="!moments.length" class="empty">
        <div class="empty-icon"><Icon name="compass" :size="30" /></div>
        <div class="empty-title">还没有动态</div>
        <div class="empty-text">发布第一条动态，分享此刻的心情</div>
        <button class="empty-btn" @click="openCompose">发布动态</button>
      </div>

      <div v-else class="moment-list">
        <div v-for="m in moments" :key="m.id" class="moment-card">
          <div class="moment-head">
            <Avatar :id="m.user?.id" :name="displayName(m.user)" :size="42" />
            <div class="mh-info">
              <div class="mh-name">
                {{ displayName(m.user) }}
                <span v-if="m.pinned" class="pin-badge">置顶</span>
              </div>
              <div class="mh-time">{{ formatTime(m.at) }}</div>
            </div>
          </div>

          <div v-if="m.text" class="moment-text">{{ m.text }}</div>

          <div v-if="m.images && m.images.length" class="moment-images" :class="'n' + Math.min(m.images.length, 3)">
            <img
              v-for="img in m.images"
              :key="img"
              :src="img"
              alt="动态图片"
              @click="preview = img"
            />
          </div>

          <div class="moment-actions">
            <button class="m-act" :class="{ on: m.liked }" @click="like(m)">
              <Icon name="heart" :size="18" />
              <span>{{ m.likeCount || 0 }}</span>
            </button>
            <button class="m-act" @click="openComments(m)">
              <Icon name="comment" :size="18" />
              <span>{{ m.comments ? m.comments.length : 0 }}</span>
            </button>
          </div>

          <div v-if="official" class="moment-mod">
            <button class="mod-btn" @click="togglePin(m)">{{ m.pinned ? '取消置顶' : '置顶' }}</button>
            <button class="mod-btn danger" @click="removeMoment(m)">删除动态</button>
          </div>

          <div v-if="m.comments && m.comments.length" class="moment-comments">
            <div v-for="c in m.comments.slice(-3)" :key="c.id" class="mc">
              <b>{{ displayName(c.user) }}</b>：{{ c.text }}
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 发布动态 -->
    <div v-if="composeVisible" class="compose-mask" @click.self="composeVisible = false">
      <div class="compose-card">
        <div class="compose-title">发布动态</div>
        <textarea
          v-model="text"
          class="compose-textarea"
          maxlength="500"
          placeholder="这一刻的想法…"
        />
        <div class="compose-images">
          <div v-for="(img, i) in images" :key="i" class="compose-thumb">
            <img :src="img" alt="" />
            <button class="thumb-del" @click="images.splice(i, 1)">×</button>
          </div>
          <button v-if="images.length < 9" class="compose-add" @click="pickImages">
            <Icon name="plus" :size="22" />
          </button>
        </div>
        <button class="publish-btn" :disabled="publishing || (!text.trim() && !images.length)" @click="publish">
          {{ publishing ? '发布中…' : '发布' }}
        </button>
        <button class="qr-close" @click="composeVisible = false">取消</button>
      </div>
    </div>

    <input ref="fileRef" type="file" accept="image/*" multiple class="hidden" @change="onFiles" />

    <!-- 评论 -->
    <Teleport to="body">
      <template v-if="commentTarget">
        <div class="mask" @click="commentTargetId = null" />
        <div class="comment-sheet">
          <div class="comment-head">
            评论
            <span class="count">{{ commentTarget.comments ? commentTarget.comments.length : 0 }}</span>
            <button class="close-x" @click="commentTargetId = null">×</button>
          </div>
          <div class="comment-list">
            <div v-if="!commentTarget.comments || !commentTarget.comments.length" class="empty" style="padding: 40px 10px">
              <div class="empty-text">还没有评论，来说第一句吧</div>
            </div>
            <div v-for="c in commentTarget.comments || []" :key="c.id" class="comment-item">
              <Avatar :id="c.user?.id" :name="displayName(c.user)" :size="34" />
              <div style="flex: 1; min-width: 0">
                <div class="c-name">{{ displayName(c.user) }}</div>
                <div class="c-text">{{ c.text }}</div>
              </div>
              <button v-if="official" class="mod-x" @click="removeComment(c)">删除</button>
            </div>
          </div>
          <div class="comment-input">
            <input v-model="commentText" placeholder="说点什么…" @keyup.enter="sendComment" />
            <button class="c-send" :disabled="!commentText.trim()" @click="sendComment">发送</button>
          </div>
        </div>
      </template>
    </Teleport>

    <div v-if="preview" class="img-preview" @click="preview = ''">
      <img :src="preview" alt="预览" />
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import {
  state,
  loadMoments,
  createMoment,
  likeMoment,
  commentMoment,
  uploadDataUrl,
  formatTime,
  isOfficial,
  displayName,
  adminTogglePin,
  adminDeleteMoment,
  adminDeleteComment
} from '../store'
import { fileToImage } from '../utils'
import { toast } from '../toast'
import { confirmDialog } from '../confirm'

const moments = computed(() => state.moments)
const official = computed(() => isOfficial())
const composeVisible = ref(false)
const text = ref('')
const images = ref([])
const publishing = ref(false)
const fileRef = ref(null)
const commentTargetId = ref(null)
const commentText = ref('')
const preview = ref('')
const commentTarget = computed(() => {
  const id = commentTargetId.value
  if (!id) return null
  return state.moments.find(m => m.id === id) || null
})

onMounted(() => {
  loadMoments().catch(() => {})
})

function openCompose() {
  text.value = ''
  images.value = []
  composeVisible.value = true
}

function pickImages() {
  fileRef.value.click()
}

async function onFiles(e) {
  const files = Array.from(e.target.files || [])
  e.target.value = ''
  const remain = 9 - images.value.length
  for (const file of files.slice(0, remain)) {
    try {
      const dataUrl = await fileToImage(file, 900, 0.68)
      images.value.push(dataUrl)
    } catch (err) {
      toast('图片处理失败')
    }
  }
}

async function publish() {
  const content = text.value.trim()
  if (!content && !images.value.length) return
  publishing.value = true
  try {
    const urls = []
    for (const img of images.value) {
      urls.push(await uploadDataUrl(img))
    }
    await createMoment(content, urls)
    composeVisible.value = false
    toast('动态已发布')
  } catch (e) {
    toast(e.message || '发布失败')
  } finally {
    publishing.value = false
  }
}

async function like(m) {
  try {
    await likeMoment(m.id)
  } catch (e) {
    toast(e.message || '操作失败')
  }
}

function openComments(m) {
  commentTargetId.value = m.id
  commentText.value = ''
}

async function sendComment() {
  const t = commentText.value.trim()
  if (!t || !commentTarget.value) return
  try {
    await commentMoment(commentTarget.value.id, t)
    commentText.value = ''
    toast('评论已发布')
  } catch (e) {
    toast(e.message || '评论失败')
  }
}

async function togglePin(m) {
  try {
    const r = await adminTogglePin(m.id)
    toast(r && r.pinned ? '已置顶' : '已取消置顶')
  } catch (e) {
    toast(e.message || '操作失败')
  }
}

async function removeMoment(m) {
  if (!(await confirmDialog('确定删除这条动态吗？删除后不可恢复。', { danger: true }))) return
  try {
    await adminDeleteMoment(m.id)
    toast('动态已删除')
  } catch (e) {
    toast(e.message || '删除失败')
  }
}

async function removeComment(c) {
  if (!commentTarget.value) return
  if (!(await confirmDialog('确定删除这条评论吗？', { danger: true }))) return
  try {
    await adminDeleteComment(commentTarget.value.id, c.id)
    toast('评论已删除')
  } catch (e) {
    toast(e.message || '删除失败')
  }
}
</script>
