<template>
  <div class="page">
    <TopBar :title="chat ? chat.title : '聊天'" back :sub="true">
      <template #right>
        <button class="icon-btn" aria-label="更多" @click="moreVisible = true">
          <Icon name="more" :size="24" />
        </button>
      </template>
    </TopBar>

    <div ref="scrollRef" class="scroll chat-body">
      <div v-if="!messages.length" class="empty" style="padding-top: 90px">
        <div class="empty-icon"><Icon name="chat" :size="30" /></div>
        <div class="empty-title">{{ chat && chat.type === 'group' ? '群聊已创建' : '你们已经是好友了' }}</div>
        <div class="empty-text">发送第一条消息，开始聊天吧</div>
      </div>

      <template v-for="(msg, index) in messages" :key="msg.id">
        <div v-if="showDay(index)" class="day-sep">{{ formatDay(msg.at) }}</div>

        <div class="msg-row" :class="{ mine: msg.fromId === meId }">
          <Avatar
            :id="msg.fromId === meId ? meId : msg.fromId"
            :name="senderName(msg)"
            :size="36"
          />
          <div class="msg-col">
            <div v-if="chat && chat.type === 'group' && msg.fromId !== meId" class="sender-name">
              {{ senderName(msg) }}
            </div>

            <div
              class="bubble"
              :class="{
                mine: msg.fromId === meId,
                img: msg.type === 'image' && !msg.recalled,
                recalled: msg.recalled,
                voice: msg.type === 'voice' && !msg.recalled
              }"
              @pointerdown="startPress($event, msg)"
              @pointermove="movePress"
              @pointerup="clearPress"
              @pointercancel="clearPress"
              @pointerleave="clearPress"
              @contextmenu.prevent
            >
              <template v-if="msg.recalled">
                {{ msg.fromId === meId ? '你撤回了一条消息' : '对方撤回了一条消息' }}
              </template>
              <template v-else-if="msg.type === 'image'">
                <img class="bubble-img" :src="msg.content" alt="图片消息" />
              </template>
              <template v-else-if="msg.type === 'voice'">
                <button class="voice-bubble" @click="playVoice(msg)">
                  <Icon name="play" :size="15" />
                  <span class="voice-bar"><i /></span>
                  <span class="voice-dur">{{ msg.duration || 1 }}"</span>
                </button>
              </template>
              <template v-else>{{ msg.content }}</template>
            </div>
            <div class="msg-time">{{ formatTime(msg.at) }}</div>
          </div>
        </div>
      </template>
    </div>

    <div v-if="recording" class="recording-bar">
      <span class="rec-dot" />
      <span>正在录音 {{ recordSeconds }}s / 10s，再次点击麦克风结束</span>
    </div>

    <div class="composer">
      <button class="icon-btn" aria-label="发送图片" @click="pickImage">
        <Icon name="image" :size="24" />
      </button>
      <button
        v-if="!draft.trim()"
        class="icon-btn"
        :class="{ 'rec-active': recording }"
        aria-label="语音消息"
        @click="toggleRecord"
      >
        <Icon name="mic" :size="24" />
      </button>
      <input
        ref="inputRef"
        v-model="draft"
        class="composer-input"
        placeholder="发消息…"
        @keyup.enter="send"
      />
      <button class="send-btn" :disabled="!draft.trim() || sending" @click="send">发送</button>
    </div>

    <input ref="fileRef" type="file" accept="image/*" class="hidden" @change="onFile" />

    <ActionSheet
      :visible="msgMenuVisible"
      :title="menuTitle"
      :items="msgMenuItems"
      @select="onMsgMenu"
      @close="msgMenuVisible = false"
    />

    <ActionSheet
      :visible="moreVisible"
      :items="moreItems"
      @select="onMore"
      @close="moreVisible = false"
    />
  </div>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Icon from '../components/Icon.vue'
import Avatar from '../components/Avatar.vue'
import ActionSheet from '../components/ActionSheet.vue'
import {
  state,
  userById,
  chatById,
  messagesOf,
  markRead,
  loadMessages,
  refresh,
  sendMessage,
  recallMessage,
  deleteMessage,
  blockUser,
  unblockUser,
  isBlocked,
  displayName,
  setActiveChat,
  uploadDataUrl,
  formatTime,
  formatDay
} from '../store'
import { fileToImage, copyText } from '../utils'
import { toast } from '../toast'
import { confirmDialog } from '../confirm'

const route = useRoute()
const router = useRouter()
const chatId = String(route.params.chatId)
const meId = computed(() => state.me?.id)

const chat = computed(() => chatById(chatId))
const messages = computed(() => messagesOf(chatId))

const draft = ref('')
const sending = ref(false)
const scrollRef = ref(null)
const inputRef = ref(null)
const fileRef = ref(null)

const moreVisible = ref(false)
const msgMenuVisible = ref(false)
const selectedMsg = ref(null)

const recording = ref(false)
const recordSeconds = ref(0)
let mediaRecorder = null
let recordChunks = []
let recordTimer = null
let recordStream = null

const menuTitle = computed(() => (selectedMsg.value ? formatTime(selectedMsg.value.at) : ''))
const msgMenuItems = computed(() => {
  const msg = selectedMsg.value
  if (!msg) return []
  const items = []
  if (msg.type === 'text' && !msg.recalled) items.push({ id: 'copy', label: '复制' })
  if (msg.fromId === meId.value && !msg.recalled) items.push({ id: 'recall', label: '撤回' })
  items.push({ id: 'delete', label: '删除', danger: true })
  return items
})

const moreItems = computed(() => {
  const peer = chat.value && chat.value.type === 'direct' ? chat.value.peer : null
  if (!peer) return []
  if (isBlocked(peer.id)) return [{ id: 'unblock', label: '移出黑名单' }]
  return [{ id: 'block', label: '加入黑名单', danger: true }]
})

function senderName(msg) {
  if (msg.fromId === meId.value) return state.me?.nickname || '我'
  return displayName(userById(msg.fromId))
}

function showDay(index) {
  if (index === 0) return true
  const prev = messages.value[index - 1]
  const cur = messages.value[index]
  return formatDay(prev.at) !== formatDay(cur.at)
}

function scrollToBottom() {
  nextTick(() => {
    const el = scrollRef.value
    if (el) el.scrollTop = el.scrollHeight
  })
}

async function boot() {
  try {
    if (!chat.value) await refresh()
    if (!chat.value) {
      toast('会话不存在或已被删除')
      return
    }
    setActiveChat(chatId)
    await loadMessages(chatId)
    markRead(chatId)
    scrollToBottom()
  } catch (e) {
    toast(e.message || '加载消息失败')
  }
}

async function send() {
  const text = draft.value.trim()
  if (!text || sending.value) return
  draft.value = ''
  sending.value = true
  try {
    await sendMessage(chatId, { type: 'text', content: text })
    scrollToBottom()
  } catch (e) {
    toast(e.message || '发送失败')
    draft.value = text
  } finally {
    sending.value = false
  }
}

function pickImage() {
  fileRef.value.click()
}

async function onFile(e) {
  const file = e.target.files && e.target.files[0]
  e.target.value = ''
  if (!file) return
  try {
    const dataUrl = await fileToImage(file)
    toast('图片上传中…')
    const url = await uploadDataUrl(dataUrl)
    await sendMessage(chatId, { type: 'image', content: url })
    scrollToBottom()
  } catch (err) {
    toast(err.message || '图片发送失败')
  }
}

/* ---------------- 语音 ---------------- */
const MAX_RECORD_SECONDS = 10

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(blob)
  })
}

function hasNativeRecorder() {
  try {
    return Boolean(
      window.XiaoduApp &&
        typeof window.XiaoduApp.startRecord === 'function' &&
        typeof window.XiaoduApp.stopRecord === 'function'
    )
  } catch (e) {
    return false
  }
}

function toggleRecord() {
  if (recording.value) {
    stopRecord()
    return
  }
  if (hasNativeRecorder()) {
    startNativeRecord()
  } else {
    startBrowserRecord()
  }
}

function startNativeRecord() {
  let ok = false
  try {
    ok = window.XiaoduApp.startRecord()
  } catch (e) {
    ok = false
  }
  if (!ok) {
    toast('请允许麦克风权限后再点一次麦克风')
    return
  }
  beginRecordTimer()
  if (navigator.vibrate) navigator.vibrate(12)
}

async function startBrowserRecord() {
  if (!navigator.mediaDevices || !window.MediaRecorder) {
    toast('当前设备/浏览器不支持录音')
    return
  }
  try {
    recordStream = await navigator.mediaDevices.getUserMedia({ audio: true })
    recordChunks = []
    let mime = ''
    const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg']
    for (const c of candidates) {
      if (window.MediaRecorder.isTypeSupported && window.MediaRecorder.isTypeSupported(c)) {
        mime = c
        break
      }
    }
    mediaRecorder = mime
      ? new MediaRecorder(recordStream, { mimeType: mime, audioBitsPerSecond: 24000 })
      : new MediaRecorder(recordStream)
    mediaRecorder.ondataavailable = e => {
      if (e.data && e.data.size) recordChunks.push(e.data)
    }
    mediaRecorder.onstop = onRecordStop
    mediaRecorder.start()
    beginRecordTimer()
    if (navigator.vibrate) navigator.vibrate(12)
  } catch (e) {
    toast('无法获取麦克风权限')
  }
}

function beginRecordTimer() {
  recording.value = true
  recordSeconds.value = 0
  clearInterval(recordTimer)
  recordTimer = setInterval(() => {
    recordSeconds.value++
    if (recordSeconds.value >= MAX_RECORD_SECONDS) stopRecord()
  }, 1000)
}

function stopRecord() {
  clearInterval(recordTimer)
  recording.value = false
  if (hasNativeRecorder()) {
    let base64 = ''
    try {
      base64 = window.XiaoduApp.stopRecord() || ''
    } catch (e) {
      base64 = ''
    }
    if (base64) {
      onRecordData('data:audio/mp4;base64,' + base64, Math.max(1, recordSeconds.value))
    }
    return
  }
  if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop()
  if (recordStream) {
    recordStream.getTracks().forEach(t => t.stop())
    recordStream = null
  }
}

async function onRecordStop() {
  const duration = Math.max(1, recordSeconds.value)
  const blob = new Blob(recordChunks, { type: mediaRecorder.mimeType || 'audio/webm' })
  recordChunks = []
  if (!blob.size) return
  const dataUrl = await blobToDataUrl(blob)
  onRecordData(dataUrl, duration)
}

async function onRecordData(dataUrl, duration) {
  try {
    toast('语音上传中…')
    const url = await uploadDataUrl(dataUrl)
    await sendMessage(chatId, { type: 'voice', content: url, duration })
    scrollToBottom()
  } catch (e) {
    toast(e.message || '语音发送失败')
  }
}

const players = {}
function playVoice(msg) {
  const key = msg.id
  if (players[key]) {
    players[key].pause()
    delete players[key]
    return
  }
  const audio = new Audio(msg.content)
  players[key] = audio
  audio.play().catch(() => toast('语音播放失败'))
  audio.onended = () => delete players[key]
}

/* ---------------- 长按消息 ---------------- */
let pressTimer = null
let pressX = 0
let pressY = 0

function startPress(e, msg) {
  pressX = e.clientX
  pressY = e.clientY
  clearPress()
  pressTimer = setTimeout(() => {
    selectedMsg.value = msg
    msgMenuVisible.value = true
    if (navigator.vibrate) navigator.vibrate(15)
  }, 480)
}

function movePress(e) {
  if (Math.abs(e.clientX - pressX) > 8 || Math.abs(e.clientY - pressY) > 8) clearPress()
}

function clearPress() {
  if (pressTimer) {
    clearTimeout(pressTimer)
    pressTimer = null
  }
}

async function onMsgMenu(id) {
  const msg = selectedMsg.value
  if (!msg) return
  if (id === 'copy') {
    const ok = await copyText(msg.content)
    toast(ok ? '已复制' : '复制失败')
  } else if (id === 'recall') {
    try {
      await recallMessage(chatId, msg.id)
      toast('已撤回')
    } catch (e) {
      toast(e.message || '撤回失败')
    }
  } else if (id === 'delete') {
    try {
      await deleteMessage(chatId, msg.id)
      toast('已删除')
    } catch (e) {
      toast(e.message || '删除失败')
    }
  }
}

async function onMore(id) {
  const peer = chat.value?.peer
  if (!peer) return
  if (id === 'block') {
    if (await confirmDialog('加入黑名单后，将解除好友关系并删除会话，对方也不能再加你或给你发消息。确定继续？', { danger: true })) {
      try {
        await blockUser(peer.id)
        toast('已加入黑名单')
        router.replace('/chats')
      } catch (e) {
        toast(e.message || '加入黑名单失败')
      }
    }
  } else if (id === 'unblock') {
    if (await confirmDialog('移出黑名单后，对方可以重新加你为好友。确定继续？')) {
      try {
        await unblockUser(peer.id)
        toast('已移出黑名单')
      } catch (e) {
        toast(e.message || '移出失败')
      }
    }
  }
}

onMounted(boot)
onBeforeUnmount(() => {
  setActiveChat(null)
  if (recording.value) stopRecord()
})

watch(
  () => messages.value.length,
  () => {
    if (recording.value) return
    scrollToBottom()
  }
)
</script>
