<template>
  <div class="page">
    <TopBar title="编辑资料" back />

    <div class="scroll">
      <div class="edit-avatar">
        <Avatar :id="me?.id" :name="me?.nickname" :size="82" />
        <button class="edit-avatar-btn" :disabled="uploading" @click="pickAvatar">
          {{ uploading ? '上传中…' : '更换头像' }}
        </button>
        <input ref="fileRef" type="file" accept="image/*" style="display: none" @change="onFile" />
      </div>

      <div class="edit-group">
        <div class="edit-row">
          <span class="edit-label">昵称</span>
          <input v-model="nickname" class="edit-input" maxlength="24" placeholder="取个名字吧" />
        </div>
        <div class="edit-row column">
          <span class="edit-label">个性签名</span>
          <textarea
            v-model="bio"
            class="edit-textarea"
            maxlength="60"
            placeholder="写一句话介绍自己"
          />
          <span class="edit-count">{{ bio.length }}/60</span>
        </div>
        <div class="edit-row">
          <span class="edit-label">账号</span>
          <span class="edit-fixed">@{{ me?.username }}</span>
        </div>
      </div>

      <div class="edit-tip">头像和昵称会立即对好友生效，账号注册后不可修改。</div>

      <button class="save-btn" :disabled="saving || uploading || !canSave" @click="save">
        {{ saving ? '保存中…' : '保存' }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import Avatar from '../components/Avatar.vue'
import { state, updateProfile, uploadAvatar } from '../store'
import { fileToImage } from '../utils'
import { toast } from '../toast'

const router = useRouter()
const me = computed(() => state.me)
const nickname = ref(me.value?.nickname || '')
const bio = ref(me.value?.bio || '')
const saving = ref(false)
const uploading = ref(false)
const fileRef = ref(null)

const canSave = computed(() => Boolean(nickname.value.trim()))

function pickAvatar() {
  if (uploading.value) return
  fileRef.value && fileRef.value.click()
}

async function onFile(e) {
  const file = e.target.files && e.target.files[0]
  e.target.value = ''
  if (!file) return
  uploading.value = true
  try {
    const dataUrl = await fileToImage(file, 480, 0.8)
    await uploadAvatar(dataUrl)
    toast('头像已更新')
  } catch (err) {
    toast(err.message || '头像上传失败')
  } finally {
    uploading.value = false
  }
}

async function save() {
  if (!canSave.value || saving.value) return
  saving.value = true
  try {
    await updateProfile({
      nickname: nickname.value.trim(),
      bio: bio.value.trim()
    })
    toast('资料已保存')
    router.replace('/me')
  } catch (err) {
    toast(err.message || '保存失败')
  } finally {
    saving.value = false
  }
}
</script>

<style scoped>
.edit-avatar {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 26px 0 20px;
}
.edit-avatar-btn {
  font-size: 13px;
  color: var(--accent, #2e6be6);
}

.edit-group {
  background: #fff;
  border-radius: 14px;
  margin: 0 16px;
  overflow: hidden;
}
.edit-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  border-bottom: 1px solid #f0f0f3;
}
.edit-row.column {
  flex-direction: column;
  align-items: stretch;
  gap: 8px;
  position: relative;
}
.edit-label {
  font-size: 13.5px;
  color: #8b8b93;
  flex: none;
}
.edit-input {
  flex: 1;
  min-width: 0;
  border: none;
  outline: none;
  font-size: 15px;
  background: transparent;
  text-align: right;
}
.edit-textarea {
  border: none;
  outline: none;
  resize: none;
  font-size: 14.5px;
  line-height: 1.5;
  min-height: 64px;
  background: transparent;
  font-family: inherit;
}
.edit-count {
  text-align: right;
  font-size: 11.5px;
  color: #b4b4bc;
}
.edit-fixed {
  flex: 1;
  text-align: right;
  font-size: 14px;
  color: #9a9aa2;
  font-family: ui-monospace, Menlo, monospace;
}
.edit-tip {
  padding: 12px 26px;
  font-size: 12px;
  color: #a3a3ab;
  line-height: 1.5;
}
.save-btn {
  display: block;
  width: calc(100% - 32px);
  margin: 6px 16px 28px;
  height: 46px;
  border-radius: 12px;
  font-size: 15.5px;
  font-weight: 700;
  color: #232300;
  background: var(--accent, #ffd60a);
}
.save-btn:disabled {
  opacity: 0.55;
}
</style>
