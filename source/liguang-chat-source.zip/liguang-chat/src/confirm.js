import { reactive } from 'vue'

/* 应用内确认弹窗：替代 window.confirm（系统弹窗会显示网址，观感很差） */

export const confirmState = reactive({
  visible: false,
  title: '提示',
  message: '',
  confirmText: '确定',
  cancelText: '取消',
  danger: false
})

let resolver = null

export function confirmDialog(message, opts = {}) {
  if (resolver) {
    resolver(false)
    resolver = null
  }
  confirmState.title = opts.title || '提示'
  confirmState.message = String(message || '')
  confirmState.confirmText = opts.confirmText || '确定'
  confirmState.cancelText = opts.cancelText || '取消'
  confirmState.danger = Boolean(opts.danger)
  confirmState.visible = true
  return new Promise(resolve => {
    resolver = resolve
  })
}

export function resolveConfirm(ok) {
  confirmState.visible = false
  const r = resolver
  resolver = null
  if (r) r(Boolean(ok))
}
