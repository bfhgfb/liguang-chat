import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './styles.css'
import { isAuthed } from './store'

router.beforeEach(async to => {
  const authed = await isAuthed()
  if (!to.meta.public && !authed) return { path: '/login' }
  if (to.path === '/login' && authed) return { path: '/chats' }
  return true
})

createApp(App).use(router).mount('#app')
