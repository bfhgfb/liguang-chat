const TOKEN_KEY = 'liguang_token'

export function getToken() {
  return localStorage.getItem(TOKEN_KEY) || ''
}

export function setToken(token) {
  if (token) localStorage.setItem(TOKEN_KEY, token)
  else localStorage.removeItem(TOKEN_KEY)
}

const BASE = (window.__API_BASE__ || '') + '/api'

export async function api(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' }
  const token = getToken()
  if (auth && token) headers.Authorization = 'Bearer ' + token

  let res
  try {
    res = await fetch(BASE + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined
    })
  } catch (e) {
    throw new Error('网络连接失败，请检查服务端是否已启动')
  }

  let data = {}
  try {
    data = await res.json()
  } catch (e) {
    /* 非 JSON 响应 */
  }

  if (!res.ok) {
    throw new Error(data.error || '请求失败（' + res.status + '）')
  }
  return data
}
