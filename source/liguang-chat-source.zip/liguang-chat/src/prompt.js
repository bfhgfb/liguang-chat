import { reactive } from 'vue'

/* 应用内输入弹窗：替代 window.prompt（WebView 里无法弹出） */

export const promptState = reactive({
  visible: false,
  title: '输入',
  placeholder: '',
  value: '',
  maxlength: 32
})

let resolver = null

export function promptDialog(title, opts = {}) {
  if (resolver) {
    resolver(null)
    resolver = null
  }
  promptState.title = title || '输入'
  promptState.placeholder = opts.placeholder || ''
  promptState.value = opts.value || ''
  promptState.maxlength = opts.maxlength || 32
  promptState.visible = true
  return new Promise(resolve => {
    resolver = resolve
  })
}

export function resolvePrompt(value) {
  promptState.visible = false
  const r = resolver
  resolver = null
  if (r) r(value)
}
