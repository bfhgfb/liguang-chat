<template>
  <Teleport to="body">
    <div v-if="visible" class="up-mask">
      <div class="up-card">
        <div class="up-title">发现新版本 {{ info.versionName }}</div>
        <div class="up-notes">{{ info.notes || '修复问题并优化体验' }}</div>
        <div class="up-actions">
          <button class="up-btn ghost" @click="later">稍后</button>
          <button class="up-btn primary" :disabled="busy" @click="update">
            {{ busy ? '正在下载…' : '立即更新' }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { toast } from '../toast'

const VERSION_URLS = [
  './apk/version.json',
  'https://dxibubacwhdsibiggqgg.supabase.co/storage/v1/object/public/site/version.json'
]

const visible = ref(false)
const busy = ref(false)
const info = reactive({ versionCode: 0, versionName: '', apkUrl: '', notes: '' })
const nativeCode = ref(0)

function readNativeCode() {
  try {
    if (window.XiaoduApp && typeof window.XiaoduApp.getVersionCode === 'function') {
      return Number(window.XiaoduApp.getVersionCode()) || 0
    }
  } catch (e) {
    /* ignore */
  }
  return 0
}

async function check() {
  nativeCode.value = readNativeCode()
  // 只有装在手机 App 里才走强制更新；浏览器里没有原生版本号
  if (!nativeCode.value) return
  for (const url of VERSION_URLS) {
    try {
      const res = await fetch(url + '?t=' + Date.now(), { cache: 'no-store' })
      if (!res.ok) continue
      const data = await res.json()
      if (!data || !data.versionCode) continue
      if (Number(data.versionCode) <= nativeCode.value) return
      info.versionCode = Number(data.versionCode)
      info.versionName = data.versionName || ''
      info.apkUrl = data.apkUrl || ''
      info.notes = data.notes || ''
      visible.value = true
      return
    } catch (e) {
      /* 这个地址取不到就换下一个 */
    }
  }
}

function later() {
  visible.value = false
}

function update() {
  if (busy.value) return
  if (!info.apkUrl) {
    toast('下载地址缺失，请稍后再试')
    return
  }
  busy.value = true
  try {
    if (window.XiaoduApp && typeof window.XiaoduApp.installApk === 'function') {
      window.XiaoduApp.installApk(info.apkUrl)
      toast('开始下载，完成后会自动安装')
      setTimeout(() => {
        busy.value = false
        visible.value = false
      }, 1200)
      return
    }
    window.open(info.apkUrl, '_blank')
    busy.value = false
    visible.value = false
  } catch (e) {
    busy.value = false
    toast('更新失败，请稍后重试')
  }
}

onMounted(() => {
  check()
})
</script>

<style scoped>
.up-mask {
  position: fixed;
  inset: 0;
  z-index: 9999;
  background: rgba(0, 0, 0, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 28px;
}
.up-card {
  width: 100%;
  max-width: 330px;
  background: #fff;
  border-radius: 18px;
  padding: 22px 20px 18px;
  text-align: center;
}
.up-title {
  font-size: 17px;
  font-weight: 700;
}
.up-notes {
  margin-top: 10px;
  font-size: 13px;
  line-height: 1.6;
  color: #8b8b93;
}
.up-actions {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}
.up-btn {
  flex: 1;
  height: 42px;
  border-radius: 12px;
  font-size: 14.5px;
  font-weight: 600;
}
.up-btn.ghost {
  background: #f2f2f6;
  color: #6f6f77;
}
.up-btn.primary {
  background: var(--accent, #ffd60a);
  color: #232300;
  font-weight: 700;
}
</style>
