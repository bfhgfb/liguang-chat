<template>
  <div class="nav">
    <div class="nav-inner">
      <button v-if="back" class="icon-btn" aria-label="返回" @click="goBack">
        <Icon name="back" :size="22" />
      </button>
      <span v-else class="nav-spacer" />

      <div class="nav-title" :class="{ left, sub }">{{ title }}</div>

      <div class="nav-right">
        <slot name="right">
          <span class="nav-spacer" />
        </slot>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import Icon from './Icon.vue'

defineProps({
  title: { type: String, default: '' },
  back: { type: Boolean, default: false },
  left: { type: Boolean, default: false },
  sub: { type: Boolean, default: false }
})

const router = useRouter()

function goBack() {
  if (window.history.length > 1) router.back()
  else router.replace('/chats')
}
</script>

<style scoped>
.nav-right { width: 38px; flex: none; display: flex; justify-content: flex-end; }
</style>
