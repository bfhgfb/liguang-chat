<template>
  <div v-if="!state.consented" class="consent-mask">
    <div class="consent-card">
      <h1 class="consent-title">欢迎使用{{ appName }}</h1>

      <p class="consent-lead">
        感谢你的信任。在开始使用前，请先花一点时间阅读并同意以下协议，以便你了解我们如何保护你的个人信息与内容安全。
      </p>

      <div class="notice-box">
        您可以通过
        <span class="link" @click="open('service')">《{{ appName }}服务协议》</span>、
        <span class="link" @click="open('privacy')">《{{ appName }}隐私协议》</span>
        了解我们如何收集、使用、存储与保护你的个人信息。你可以随时在「我-设置-隐私」中查看并管理授权。
      </div>

      <p class="consent-hint">
        如您同意以上内容，请点击“同意”开始使用{{ appName }}；如您不同意，将无法使用本应用的相关服务。
      </p>

      <div class="consent-actions">
        <button class="btn btn-ghost" @click="onDisagree">不同意</button>
        <button class="btn btn-primary" @click="onAgree">同意</button>
      </div>
    </div>

    <LegalSheet :visible="legalVisible" :type="legalType" @close="legalVisible = false" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { APP_NAME } from '../legal'
import { state, setConsented } from '../store'
import { toast } from '../toast'
import LegalSheet from './LegalSheet.vue'

const appName = APP_NAME
const legalVisible = ref(false)
const legalType = ref('service')

const disagreeCopy = ['需同意后才能开始使用', '可以先阅读两份协议，再点击“同意”']
let disagreeIndex = 0

function open(type) {
  legalType.value = type
  legalVisible.value = true
}

function onAgree() {
  setConsented(true)
  toast('已同意协议，欢迎使用' + appName)
}

function onDisagree() {
  toast(disagreeCopy[disagreeIndex % disagreeCopy.length])
  disagreeIndex++
}
</script>
