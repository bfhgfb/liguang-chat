<template>
  <div class="avatar" :style="style">
    <img v-if="srcUrl" :src="srcUrl" alt="" />
    <span v-else>{{ glyph }}</span>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { userById } from '../store'

const props = defineProps({
  id: { type: String, default: '' },
  name: { type: String, default: '' },
  src: { type: String, default: '' },
  size: { type: Number, default: 44 }
})

const PALETTE = [
  ['#FFE36E', '#FFC933'],
  ['#BFD7FF', '#8FB4FF'],
  ['#FFD3C4', '#FFB59A'],
  ['#C9F0D6', '#9BDFB5'],
  ['#E3D0FF', '#BFA2FF'],
  ['#FFE0F0', '#FFB3DA'],
  ['#D6F0FF', '#9ED3FF'],
  ['#F5E6C8', '#E5C98F'],
  ['#D9F2EA', '#9FDCC9'],
  ['#E8E4FF', '#B9B0FF']
]

function hash(str) {
  let h = 0
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0
  return h
}

const srcUrl = computed(() => {
  if (props.src) return props.src
  const user = userById(props.id)
  return (user && user.avatar_url) || ''
})

const isOfficialAvatar = computed(() => {
  if (props.src) return false
  const user = userById(props.id)
  return Boolean(user && user.is_official)
})

const glyph = computed(() => {
  const id = props.id || props.name
  if (id === 'LG-FILE') return '📁'
  if (id === 'LG-ME01') return '璃'
  if (props.name) return props.name.slice(0, 1)
  return id ? id.slice(-1) : '?'
})

const style = computed(() => {
  const p = PALETTE[hash(props.id || props.name || '?') % PALETTE.length]
  const base = {
    width: props.size + 'px',
    height: props.size + 'px',
    borderRadius: Math.round(props.size * 0.24) + 'px',
    fontSize: Math.round(props.size * 0.42) + 'px',
    background: `linear-gradient(135deg, ${p[0]}, ${p[1]})`
  }
  if (srcUrl.value) base.background = '#ebeaf2'
  if (isOfficialAvatar.value) base.boxShadow = '0 0 0 2px #f6c453, 0 0 10px rgba(246, 196, 83, 0.45)'
  return base
})
</script>

<style scoped>
.avatar {
  flex: none;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #3a3a2a;
  font-weight: 700;
  user-select: none;
  overflow: hidden;
}
.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
</style>
