<template>
  <Teleport to="body">
    <div v-if="confirmState.visible" class="consent-mask" @click.self="resolveConfirm(false)">
      <div class="consent-card confirm-card">
        <h2 class="consent-title">{{ confirmState.title }}</h2>
        <p class="confirm-text">{{ confirmState.message }}</p>
        <div class="consent-actions">
          <button class="btn btn-ghost" @click="resolveConfirm(false)">
            {{ confirmState.cancelText }}
          </button>
          <button
            class="btn"
            :class="confirmState.danger ? 'btn-danger' : 'btn-primary'"
            @click="resolveConfirm(true)"
          >
            {{ confirmState.confirmText }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { confirmState, resolveConfirm } from '../confirm'
</script>
