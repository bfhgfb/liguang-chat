<template>
  <Teleport to="body">
    <div v-if="visible" class="legal">
      <div class="legal-head">
        <div class="legal-title">{{ doc.title }}</div>
        <button class="legal-close" aria-label="关闭" @click="$emit('close')">×</button>
      </div>
      <div class="legal-body">
        <div class="legal-sheet">
          <h2>{{ doc.title }}</h2>
          <p class="legal-updated">{{ doc.updated }}</p>
          <template v-for="(sec, i) in doc.sections" :key="i">
            <h3>{{ sec.h }}</h3>
            <p v-for="(p, j) in sec.ps || []" :key="'p' + j">{{ p }}</p>
            <ul v-if="sec.ul && sec.ul.length">
              <li v-for="(li, k) in sec.ul" :key="'l' + k">{{ li }}</li>
            </ul>
          </template>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { computed } from 'vue'
import { DOCS } from '../legal'

const props = defineProps({
  visible: { type: Boolean, default: false },
  type: { type: String, default: 'service' }
})
defineEmits(['close'])

const doc = computed(() => DOCS[props.type] || DOCS.service)
</script>
