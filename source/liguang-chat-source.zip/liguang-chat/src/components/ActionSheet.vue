<template>
  <Teleport to="body">
    <template v-if="visible">
      <div class="mask" @click="$emit('close')" />
      <div class="sheet">
        <div v-if="title" class="sheet-title">{{ title }}</div>
        <div class="sheet-list">
          <button
            v-for="item in items"
            :key="item.id"
            class="sheet-item"
            :class="{ danger: item.danger }"
            @click="pick(item)"
          >
            {{ item.label }}
          </button>
        </div>
        <button class="sheet-cancel" @click="$emit('close')">取消</button>
      </div>
    </template>
  </Teleport>
</template>

<script setup>
const props = defineProps({
  visible: { type: Boolean, default: false },
  title: { type: String, default: '' },
  items: { type: Array, default: () => [] }
})
const emit = defineEmits(['close', 'select'])

function pick(item) {
  emit('select', item.id)
  emit('close')
}
</script>
