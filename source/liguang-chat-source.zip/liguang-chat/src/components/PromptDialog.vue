<template>
  <Teleport to="body">
    <div v-if="promptState.visible" class="consent-mask" @click.self="resolvePrompt(null)">
      <div class="consent-card prompt-card">
        <h2 class="consent-title">{{ promptState.title }}</h2>
        <input
          ref="inputRef"
          v-model="value"
          class="prompt-input"
          :placeholder="promptState.placeholder"
          :maxlength="promptState.maxlength"
          @keyup.enter="submit"
        />
        <div class="consent-actions">
          <button class="btn btn-ghost" @click="resolvePrompt(null)">取消</button>
          <button class="btn btn-primary" @click="submit">保存</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { nextTick, ref, watch } from 'vue'
import { promptState, resolvePrompt } from '../prompt'

const value = ref('')
const inputRef = ref(null)

watch(
  () => promptState.visible,
  visible => {
    if (!visible) return
    value.value = promptState.value
    nextTick(() => {
      if (inputRef.value) inputRef.value.focus()
    })
  }
)

function submit() {
  resolvePrompt(value.value)
}
</script>

<style scoped>
.prompt-card {
  width: min(88vw, 340px);
}
.prompt-input {
  width: 100%;
  height: 44px;
  margin: 6px 0 16px;
  padding: 0 14px;
  border-radius: 12px;
  border: 1px solid rgba(20, 20, 26, 0.12);
  background: #fff;
  font-size: 15px;
  color: #14141a;
  outline: none;
}
.prompt-input:focus {
  border-color: rgba(46, 107, 230, 0.55);
  box-shadow: 0 0 0 3px rgba(46, 107, 230, 0.12);
}
</style>
