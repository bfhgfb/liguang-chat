<template>
  <div class="toast" :class="{ show: toastState.show }">{{ toastState.msg }}</div>
</template>

<script setup>
import { toastState } from '../toast'
</script>
