<template>
  <nav class="tabbar">
    <button
      v-for="tab in tabs"
      :key="tab.key"
      class="tab"
      :class="{ active: current === tab.key }"
      @click="go(tab.path)"
    >
      <Icon :name="tab.icon" :size="23" />
      <span>{{ tab.label }}</span>
      <span v-if="tab.key === 'chats' && totalUnread" class="tab-badge">
        {{ totalUnread > 99 ? '99+' : totalUnread }}
      </span>
    </button>
  </nav>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Icon from './Icon.vue'
import { totalUnread } from '../store'

const route = useRoute()
const router = useRouter()

const tabs = [
  { key: 'chats', label: '消息', icon: 'chat', path: '/chats' },
  { key: 'contacts', label: '联系人', icon: 'contacts', path: '/contacts' },
  { key: 'moments', label: '动态', icon: 'compass', path: '/moments' },
  { key: 'me', label: '我', icon: 'me', path: '/me' }
]

const current = computed(() => route.meta.tab || '')

function go(path) {
  if (route.path !== path) router.push(path)
}
</script>
