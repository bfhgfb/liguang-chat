import { createClient } from '@supabase/supabase-js'

export const SUPABASE_URL = 'https://dxibubacwhdsibiggqgg.supabase.co'
export const SUPABASE_KEY = 'sb_publishable_B2KCBqcCYwSz8CmdQ8tRRw_vyUljrco'

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false
  }
})
