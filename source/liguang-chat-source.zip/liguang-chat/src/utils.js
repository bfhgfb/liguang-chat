/* 把图片压缩成可存储的 dataURL（避免 localStorage 超限） */
export function fileToImage(file, maxSize = 720, quality = 0.7) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = reject
    reader.onload = () => {
      const img = new Image()
      img.onerror = reject
      img.onload = () => {
        let { width, height } = img
        if (width > maxSize || height > maxSize) {
          if (width > height) {
            height = Math.round((height * maxSize) / width)
            width = maxSize
          } else {
            width = Math.round((width * maxSize) / height)
            height = maxSize
          }
        }
        const canvas = document.createElement('canvas')
        canvas.width = width
        canvas.height = height
        const ctx = canvas.getContext('2d')
        ctx.drawImage(img, 0, 0, width, height)
        resolve(canvas.toDataURL('image/jpeg', quality))
      }
      img.src = reader.result
    }
    reader.readAsDataURL(file)
  })
}

export async function copyText(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text)
      return true
    }
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    const ok = document.execCommand('copy')
    document.body.removeChild(ta)
    return ok
  } catch (e) {
    return false
  }
}

/* 由用户 ID 生成一个确定性的二维码示意矩阵 */
export function qrMatrix(seed, size = 21) {
  let h = 0
  const str = String(seed)
  for (let i = 0; i < str.length; i++) {
    h = (h * 31 + str.charCodeAt(i)) >>> 0
  }
  const cells = []
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const inFinder =
        (x < 7 && y < 7) || (x >= size - 7 && y < 7) || (x < 7 && y >= size - 7)
      if (inFinder) {
        const lx = x < 7 ? x : x - (size - 7)
        const ly = y < 7 ? y : y - (size - 7)
        const border = lx === 0 || lx === 6 || ly === 0 || ly === 6
        const core = lx >= 2 && lx <= 4 && ly >= 2 && ly <= 4
        cells.push({ on: border || core })
      } else {
        h = (h * 1103515245 + 12345 + x * 73856093 + y * 19349663) >>> 0
        cells.push({ on: ((h >>> 16) & 1) === 1 })
      }
    }
  }
  return cells
}
