import { createRouter, createWebHashHistory } from 'vue-router'

import Login from './views/Login.vue'
import Chats from './views/Chats.vue'
import Chat from './views/Chat.vue'
import Contacts from './views/Contacts.vue'
import AddFriend from './views/AddFriend.vue'
import Requests from './views/Requests.vue'
import Moments from './views/Moments.vue'
import Me from './views/Me.vue'
import Profile from './views/Profile.vue'
import ProfileEdit from './views/ProfileEdit.vue'
import Scan from './views/Scan.vue'
import Settings from './views/Settings.vue'
import Admin from './views/Admin.vue'

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/', redirect: '/chats' },
    { path: '/login', component: Login, meta: { public: true } },
    { path: '/chats', component: Chats, meta: { tab: 'chats' } },
    { path: '/chat/:chatId', component: Chat, meta: { tab: null } },
    { path: '/contacts', component: Contacts, meta: { tab: 'contacts' } },
    { path: '/add-friend', component: AddFriend, meta: { tab: null } },
    { path: '/add', component: AddFriend, meta: { tab: null } },
    { path: '/requests', component: Requests, meta: { tab: null } },
    { path: '/moments', component: Moments, meta: { tab: 'moments' } },
    { path: '/me', component: Me, meta: { tab: 'me' } },
    { path: '/profile/:id', component: Profile, meta: { tab: null } },
    { path: '/profile-edit', component: ProfileEdit, meta: { tab: null } },
    { path: '/scan', component: Scan, meta: { tab: null } },
    { path: '/settings', component: Settings, meta: { tab: null } },
    { path: '/admin', component: Admin, meta: { tab: null } },
    { path: '/:pathMatch(.*)*', redirect: '/chats' }
  ],
  scrollBehavior() {
    return { top: 0 }
  }
})

export default router
