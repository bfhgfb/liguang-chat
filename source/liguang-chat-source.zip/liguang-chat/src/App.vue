<template>
  <div class="shell">
    <div class="view">
      <router-view />
    </div>
    <TabBar v-if="route.meta.tab" />
    <ConsentDialog v-if="!state.consented" />
    <ConfirmDialog />
    <PromptDialog />
    <UpdatePrompt />
    <ToastHost />
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import TabBar from './components/TabBar.vue'
import ConsentDialog from './components/ConsentDialog.vue'
import ConfirmDialog from './components/ConfirmDialog.vue'
import PromptDialog from './components/PromptDialog.vue'
import UpdatePrompt from './components/UpdatePrompt.vue'
import ToastHost from './components/ToastHost.vue'
import { state, initAuth, loadMoments } from './store'

const route = useRoute()
const router = useRouter()

onMounted(async () => {
  const ok = await initAuth()
  if (ok) {
    loadMoments().catch(() => {})
    if (route.path === '/login') router.replace('/chats')
  } else if (!route.meta.public) {
    router.replace('/login')
  }
})
</script>
