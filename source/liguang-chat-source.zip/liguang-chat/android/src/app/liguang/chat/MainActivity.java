package app.liguang.chat;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

public class MainActivity extends Activity {

    private static final String SITE = "https://bfhgfb.github.io/liguang-chat/";
    private static final int REQ_FILE = 1001;
    private static final int REQ_PERMISSION = 1002;
    private static final int REQ_RECORD_AUDIO = 1003;

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingRequest;
    private String[] pendingResources;

    private MediaRecorder recorder;
    private File recordFile;

    private DownloadManager downloadManager;
    private long downloadId = -1;

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            if (id != downloadId) return;
            try {
                installDownloaded();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "安装包下载完成，请到通知栏点击安装", Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(0xFFF2F2F6);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(intent, "选择文件"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                String[] resources = request.getResources();
                // 需要相机（扫一扫）或麦克风（语音消息）时才继续
                String[] wanted = null;
                for (String r : resources) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                        wanted = new String[]{Manifest.permission.CAMERA};
                    } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                        wanted = new String[]{Manifest.permission.RECORD_AUDIO};
                    }
                }
                if (wanted == null) {
                    request.deny();
                    return;
                }
                if (checkSelfPermission(wanted[0]) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(resources);
                } else {
                    pendingRequest = request;
                    pendingResources = resources;
                    requestPermissions(wanted, REQ_PERMISSION);
                }
            }
        });

        web.addJavascriptInterface(new AppBridge(), "XiaoduApp");

        downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(downloadReceiver, filter);
        }

        web.loadUrl(SITE);
    }

    /** WebView 暴露给网页的接口：版本号 / 应用内更新安装 */
    public class AppBridge {
        @JavascriptInterface
        public int getVersionCode() {
            try {
                if (Build.VERSION.SDK_INT >= 28) {
                    return (int) getPackageManager()
                            .getPackageInfo(getPackageName(), 0).getLongVersionCode();
                }
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            } catch (Exception e) {
                return 0;
            }
        }

        @JavascriptInterface
        public String getVersionName() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void installApk(final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startDownload(url);
                }
            });
        }

        @JavascriptInterface
        public boolean startRecord() {
            if (Build.VERSION.SDK_INT >= 23 &&
                    MainActivity.this.checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.this.requestPermissions(
                                new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
                    }
                });
                return false;
            }
            return MainActivity.this.startRecordInternal();
        }

        @JavascriptInterface
        public String stopRecord() {
            return MainActivity.this.stopRecordInternal();
        }
    }

    private synchronized boolean startRecordInternal() {
        if (recorder != null) return false;
        try {
            recordFile = new File(getCacheDir(), "voice_" + System.currentTimeMillis() + ".m4a");
            if (Build.VERSION.SDK_INT >= 31) {
                recorder = new MediaRecorder(this);
            } else {
                recorder = new MediaRecorder();
            }
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioChannels(1);
            recorder.setAudioSamplingRate(44100);
            recorder.setAudioEncodingBitRate(24000);
            recorder.setMaxDuration(10000);
            recorder.setOutputFile(recordFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            return true;
        } catch (Exception e) {
            if (recorder != null) {
                try { recorder.release(); } catch (Exception ignored) {}
                recorder = null;
            }
            if (recordFile != null) {
                recordFile.delete();
                recordFile = null;
            }
            return false;
        }
    }

    private synchronized String stopRecordInternal() {
        if (recorder == null) return "";
        try { recorder.stop(); } catch (Exception ignored) {}
        try { recorder.release(); } catch (Exception ignored) {}
        recorder = null;
        String base64 = "";
        if (recordFile != null && recordFile.exists() && recordFile.length() > 0) {
            try {
                base64 = Base64.encodeToString(readFully(recordFile), Base64.NO_WRAP);
            } catch (Exception ignored) {}
            recordFile.delete();
        }
        recordFile = null;
        return base64;
    }

    private byte[] readFully(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }

    private void startDownload(String url) {
        if (url == null || url.isEmpty()) return;
        Toast.makeText(this, "开始下载新版本…", Toast.LENGTH_SHORT).show();
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setTitle("小杜 新版本");
            req.setDescription("下载完成后会自动弹出安装");
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "xiaodu-update.apk");
            downloadId = downloadManager.enqueue(req);

            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "下载失败，请用浏览器打开下载链接", Toast.LENGTH_LONG).show();
        }
    }

    private void installDownloaded() {
        Uri apkUri = downloadManager.getUriForDownloadedFile(downloadId);
        Intent install = new Intent(Intent.ACTION_VIEW);
        install.setDataAndType(apkUri, "application/vnd.android.package-archive");
        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(install);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    results = new Uri[clip.getItemCount()];
                    for (int i = 0; i < clip.getItemCount(); i++) {
                        results[i] = clip.getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_RECORD_AUDIO) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(this,
                    granted ? "麦克风权限已开启，请再点一次麦克风" : "未获得麦克风权限，无法录音",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (requestCode == REQ_PERMISSION && pendingRequest != null) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                pendingRequest.grant(pendingResources);
            } else {
                pendingRequest.deny();
            }
            pendingRequest = null;
            pendingResources = null;
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        stopRecordInternal();
        try {
            unregisterReceiver(downloadReceiver);
        } catch (Exception ignored) {
        }
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
