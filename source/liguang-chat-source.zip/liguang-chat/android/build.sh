#!/usr/bin/env bash
set -euo pipefail

SDK="${ANDROID_HOME:-/root/android-sdk}"
BT="$SDK/build-tools/36.0.0"
PLATFORM="$SDK/platforms/android-34/android.jar"
OUT="build"
KS="keystore/liguang.jks"
KS_PASS="${KS_PASS:-替换成你自己的签名密码}"
KS_ALIAS="liguang"

mkdir -p "$OUT/classes" "$OUT/dex" keystore

if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -alias "$KS_ALIAS" -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=LiGuang, OU=App, O=LiGuang, L=Beijing, ST=Beijing, C=CN"
fi

rm -f "$OUT/res.zip" "$OUT/base.apk" "$OUT/unsigned.apk" "$OUT/aligned.apk" "$OUT/liguang-chat.apk"
rm -rf "$OUT/classes" "$OUT/dex"
mkdir -p "$OUT/classes" "$OUT/dex"

echo "[1/6] compile resources"
"$BT/aapt2" compile --dir res -o "$OUT/res.zip"

echo "[2/6] link resources"
"$BT/aapt2" link -o "$OUT/base.apk" -I "$PLATFORM" \
  --manifest AndroidManifest.xml -R "$OUT/res.zip" --auto-add-overlay \
  --min-sdk-version 24 --target-sdk-version 34

echo "[3/6] compile java"
javac --release 8 -Xlint:-options -cp "$PLATFORM" -d "$OUT/classes" $(find src -name '*.java')

echo "[4/6] dex"
"$BT/d8" --release --min-api 24 --lib "$PLATFORM" --output "$OUT/dex" \
  $(find "$OUT/classes" -name '*.class')

echo "[5/6] package"
cp "$OUT/base.apk" "$OUT/unsigned.apk"
( cd "$OUT" && zip -q -j unsigned.apk dex/classes.dex )
"$BT/zipalign" -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

echo "[6/6] sign"
"$BT/apksigner" sign --ks "$KS" --ks-key-alias "$KS_ALIAS" \
  --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --out "$OUT/liguang-chat.apk" "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs "$OUT/liguang-chat.apk"
ls -lh "$OUT/liguang-chat.apk"
